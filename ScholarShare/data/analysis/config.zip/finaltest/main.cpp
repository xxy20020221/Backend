#include<bits/stdc++.h>
#include<cassert>
using namespace std;
string text;
int currentBlockid = 0;
int needAnswer1 = 0,needAnswer2 = 0,needAnswer3 = 0,needAnswer4 = 0;
enum class tokenType {
    IDENFR,INTCON,STRCON,MAINTK,CONSTTK,INTTK,BREAKTK,
    CONTINUETK,IFTK,
    ELSETK,NOT,AND,OR,FORTK,GETINTTK,PRINTFTK,RETURNTK,
    PLUS,MINU,VOIDTK,MULT,DIV,MOD,LSS,LEQ,
    GRE,GEQ,EQL,NEQ,ASSIGN,SEMICN,COMMA,
    LPARENT,RPARENT,LBRACK,RBRACK,LBRACE,
    RBRACE,UNKNOWN
};
enum MipsDataClass{
	word,
	asciiz,
	space,
};
enum MipsTextClass{
	explaint,
	LABEL,
	addiu,
	MOVE,
	syscall,
	li,
	la,
	bnez,
	beqz,
	j,
	jr,
	jal,
	sw,
	lw,
	sll,
	add,
	sub,
	mult,
	DIV,
	mflo,
	mfhi,
	sle,
	sge,
	sgt,
	seq,
	sne,	
};
map<MipsTextClass,string> MipsTextClass2string= {
    {MipsTextClass::explaint, "explaint"},
    {MipsTextClass::LABEL, "label"},
    {MipsTextClass::addiu,"addiu"},
    {MipsTextClass::MOVE,"move"},
    {MipsTextClass::syscall,"syscall"},
    {MipsTextClass::li,"li"},
    {MipsTextClass::la,"la"},
    {MipsTextClass::beqz,"beqz"},
    {MipsTextClass::bnez,"bnez"},
    {MipsTextClass::j,"j"},
    {MipsTextClass::jr,"jr"},
    {MipsTextClass::jal,"jal"},
    {MipsTextClass::sw,"sw"},
    {MipsTextClass::lw,"lw"},
    {MipsTextClass::sll,"sll"},
    {MipsTextClass::add,"addu"},
    {MipsTextClass::sub,"subu"},
    {MipsTextClass::mult,"mult"},
    {MipsTextClass::DIV,"div"},
    {MipsTextClass::mflo,"mflo"},
    {MipsTextClass::mfhi,"mfhi"},
    {MipsTextClass::sle,"sle"},
    {MipsTextClass::sge,"sge"},
    {MipsTextClass::sgt,"sgt"},
    {MipsTextClass::seq,"seq"},
    {MipsTextClass::sne,"sne"}
};
string tokenType2string(tokenType type){
    switch (type) {
        case tokenType::IDENFR:
            return "IDENFR";
        case tokenType::INTCON:
            return "INTCON";
        case tokenType::STRCON:
            return "STRCON";
        case tokenType::MAINTK:
            return "MAINTK";
        case tokenType::CONSTTK:
            return "CONSTTK";
        case tokenType::INTTK:
            return "INTTK";
        case tokenType::BREAKTK:
            return "BREAKTK";
        case tokenType::CONTINUETK:
            return "CONTINUETK";
        case tokenType::IFTK:
            return "IFTK";
        case tokenType::ELSETK:
            return "ELSETK";
        case tokenType::NOT:
            return "NOT";
        case tokenType::AND:
            return "AND";
        case tokenType::OR:
            return "OR";
        case tokenType::FORTK:
            return "FORTK";
        case tokenType::GETINTTK:
            return "GETINTTK";
        case tokenType::PRINTFTK:
            return "PRINTFTK";
        case tokenType::RETURNTK:
            return "RETURNTK";
        case tokenType::PLUS:
            return "PLUS";
        case tokenType::MINU:
            return "MINU";
        case tokenType::VOIDTK:
            return "VOIDTK";
        case tokenType::MULT:
            return "MULT";
        case tokenType::DIV:
            return "DIV";
        case tokenType::MOD:
            return "MOD";
        case tokenType::LSS:
            return "LSS";
        case tokenType::LEQ:
            return "LEQ";
        case tokenType::GRE:
            return "GRE";
        case tokenType::GEQ:
            return "GEQ";
        case tokenType::EQL:
            return "EQL";
        case tokenType::NEQ:
            return "NEQ";
        case tokenType::ASSIGN:
            return "ASSIGN";
        case tokenType::SEMICN:
            return "SEMICN";
        case tokenType::COMMA:
            return "COMMA";
        case tokenType::LPARENT:
            return "LPARENT";
        case tokenType::RPARENT:
            return "RPARENT";
        case tokenType::LBRACK:
            return "LBRACK";
        case tokenType::RBRACK:
            return "RBRACK";
        case tokenType::LBRACE:
            return "LBRACE";
        case tokenType::RBRACE:
            return "RBRACE";
        default:
            return "UNKNOWN";
    }
}
enum class GrammarItem {
    // do NOT need to print
    BlockItem,
    BType,
    Decl,
    // need print
    CompUnit,
    ConstDecl,
    VarDecl,
    ConstDef,
    ConstInitVal,
    VarDef,
    InitVal,
    FuncDef,
    MainFuncDef,
    FuncType,
    FuncFParams,
    FuncFParam,
    Block,
    Stmt,
    Exp,
    Cond,
    LVal,
    PrimaryExp,
    Number,
    UnaryExp,
    UnaryOp,
    FuncRParams,
    MulExp,
    AddExp,
    RelExp,
    EqExp,
    LAndExp,
    LOrExp,
    ConstExp,
    ForStmt,
    FormatString,
    IntConst,
    OtherLeaf,
    UNKNOWN,
    NullError
};
enum symbolTableKind {
    Function,
    Param,
    Const,
    Var,
    NoneKind
};
enum symbolTableType {
    Int,
    Array1,
    Array2,
    Void,
    NoneType
};
string symbolTableType2String(symbolTableType type){
    switch (type)
    {
    case Int:
        return "Int";
        break;
    case Void:
        return "Void";
        break;
    case Array1:
        return "Array1";
        break;
    case Array2:
        return "Array2";
        break;
    case NoneType:
        return "NoneType";
        break;
    
    
    default:
        return "unknown";
        break;
    }
}
enum class opType{
	undefine,
	null,
	plus, 			//#arg3 = arg1 + arg2
	minu,			//#arg3 = arg1 - arg2
	mult,			//#arg3 = arg1 * arg2
	DIV,			//#arg3 = arg1 / arg2
	mod,			//#arg3 = arg1 % arg2
	lss,			//#arg3 = arg1 < arg2
	leq,			//#arg3 = arg1 <= arg2
	gre,			//#arg3 = arg1 > arg2
	geq,			//#arg3 = arg1 >= arg2
	eql,			//#arg3 = arg1 == arg2
	neq,			//#arg3 = arg1 != arg2
	
	mov,			//arg3 = arg1
	neg,			//arg3 = -arg1
	NOT,			//arg3 = !arg1
	
	save,			//arg3:index	arg1:saveindex	save $t+arg3 to $s+arg1
	load,			//arg3:index	arg1:saveindex	load $t+arg3 from $s+arg3
	
	alloc,			//#allocate size(arg2) to var(arg1) ,arg3 dim
	li,				//arg3 = arg1
	lw,				//arg3 = arg1[arg2]
	sw,				//arg1[arg2(byte)] = arg3
	address,		//arg3 = &arg1[arg2(byte)]
	
	func_begin,		//#fun arg1 begin	arg3 funcIndex
	func_end,		//#fun arg1 end		arg3 funcIndex
	fparam,			//#set arg1 as NO.(arg3) param
	func_return,	//#return arg1		arg3 funcIndex
	
	call,			//#call arg1
	rparam,			//#set arg1 as NO.(arg3) param of funName(arg2)
	
	print_string,	//#print arg1
	print_int,		//#print &arg1
	get_int,		//#arg3 = getint();
	
	if_begin,		//#arg1:condition arg3:ifIndex arg2:and/or
	else_begin,		//#arg3:ifIndex
	if_end,			//#arg3:ifIndex
	
	for_begin,		//#arg3:forIndex
	for_cond,		//#arg1:condition arg3:forIndex
	for_auto,		//#arg3:forIndex
	for_end,		//#arg3:forIndex
	for_break,		//#arg3:forIndex
	for_continue,	//#arg3:forIndex
};
enum checkStatus {
    Correct,
    IllegalSymbols,         // An illegal symbol appears in the formatstring.
    Redefine,               // The variable name is defined multiple times.
    Undefined,              // The variable name is NOT yet defined.
    ParamNumberMismatch,    // The number of function parameters does NOT match.
    ParamTypeMismatch,      // Function parameter types do NOT match.
    ReturnMismatch,         // Functions with no return value have mismatched return statements.
    ReturnLack,             // Functions with return values are missing the return statement.
    ModifyConst,            // You cannot change the value of a constant.
    SEMICNLack,             // Missing ";"
    RPARENTLack,            // Missing ")"
    RBRACKLack,             // Missing "]"
    FormatNumberMismatch,   // The format characters in printf do NOT match the number of expressions.
    BreakOrContinueMismatch // Use break and continue statements in acyclic blocks.
};
vector<pair<int, checkStatus> > errorList;
map<checkStatus, string> errorCode = {
        {IllegalSymbols, "a"},
        {Redefine, "b"},
        {Undefined, "c"},
        {ParamNumberMismatch, "d"},
        {ParamTypeMismatch, "e"},
        {ReturnMismatch, "f"},
        {ReturnLack, "g"},
        {ModifyConst, "h"},
        {SEMICNLack, "i"},
        {RPARENTLack, "j"},
        {RBRACKLack, "k"},
        {FormatNumberMismatch, "l"},
        {BreakOrContinueMismatch, "m"}
};
map<GrammarItem, string> grammarItem2string = {
        {GrammarItem::BlockItem,    "<BlockItem>"},
        {GrammarItem::BType,        "<BType>"},
        {GrammarItem::Decl,         "<Decl>"},
        {GrammarItem::CompUnit,     "<CompUnit>"},
        {GrammarItem::ConstDecl,    "<ConstDecl>"},
        {GrammarItem::VarDecl,      "<VarDecl>"},
        {GrammarItem::ConstDef,     "<ConstDef>"},
        {GrammarItem::ConstInitVal, "<ConstInitVal>"},
        {GrammarItem::VarDef,       "<VarDef>"},
        {GrammarItem::InitVal,      "<InitVal>"},
        {GrammarItem::FuncDef,      "<FuncDef>"},
        {GrammarItem::MainFuncDef,  "<MainFuncDef>"},
        {GrammarItem::FuncType,     "<FuncType>"},
        {GrammarItem::FuncFParams,  "<FuncFParams>"},
        {GrammarItem::FuncFParam,   "<FuncFParam>"},
        {GrammarItem::Block,        "<Block>"},
        {GrammarItem::Stmt,         "<Stmt>"},
        {GrammarItem::Exp,          "<Exp>"},
        {GrammarItem::Cond,         "<Cond>"},
        {GrammarItem::LVal,         "<LVal>"},
        {GrammarItem::PrimaryExp,   "<PrimaryExp>"},
        {GrammarItem::Number,       "<Number>"},
        {GrammarItem::UnaryExp,     "<UnaryExp>"},
        {GrammarItem::UnaryOp,      "<UnaryOp>"},
        {GrammarItem::FuncRParams,  "<FuncRParams>"},
        {GrammarItem::MulExp,       "<MulExp>"},
        {GrammarItem::AddExp,       "<AddExp>"},
        {GrammarItem::RelExp,       "<RelExp>"},
        {GrammarItem::EqExp,        "<EqExp>"},
        {GrammarItem::LAndExp,      "<LAndExp>"},
        {GrammarItem::LOrExp,       "<LOrExp>"},
        {GrammarItem::ConstExp,     "<ConstExp>"},
        {GrammarItem::ForStmt,     "<ForStmt>"},
        {GrammarItem::FormatString,     "<Formatstring>"},
        {GrammarItem::IntConst,     "<IntConst>"},
};

map<opType, string> opType2string = {
        {opType::undefine, "undefine"},
        {opType::plus, "plus"},
        {opType::minu, "minu"},
        {opType::mult, "mult"},
        {opType::DIV, "div"},
        {opType::mod, "mod"},
        {opType::lss, "lss"},
        {opType::leq, "leq"},
        {opType::gre, "gre"},
        {opType::geq, "geq"},
        {opType::eql, "eql"},
        {opType::neq, "neq"},
        {opType::mov, "mov"},
        {opType::neg, "neg"},
        {opType::NOT, "NOT"},
        {opType::save, "save"},
        {opType::load, "load"},
        {opType::alloc, "alloc"},
        {opType::li, "li"},
        {opType::lw, "lw"},
        {opType::sw, "sw"},
        {opType::address, "address"},
        {opType::func_begin, "func_begin"},
        {opType::func_end, "func_end"},
        {opType::fparam, "fparam"},
        {opType::func_return, "func_return"},
        {opType::call, "call"},
        {opType::rparam, "rparam"},
        {opType::print_string, "print_string"},
        {opType::print_int, "print_int"},
        {opType::get_int, "get_int"},
        {opType::if_begin, "if_begin"},
        {opType::else_begin, "else_begin"},
        {opType::if_end, "if_end"},
        {opType::for_begin, "for_begin"},
        {opType::for_cond, "for_cond"},
        {opType::for_auto,"for_auto"},
        {opType::for_end,"for_end"},
        {opType::for_break,"for_break"},
        {opType::for_continue,"for_continue"},

};        

map<string, tokenType> keywordsMap = {

        {"if", tokenType::IFTK}, {"int", tokenType::INTTK},
        {"main", tokenType::MAINTK}, {"continue", tokenType::CONTINUETK},
        {"const", tokenType::CONSTTK}, {"break", tokenType::BREAKTK},
        {"else", tokenType::ELSETK}, {"for", tokenType::FORTK},
        {"getint", tokenType::GETINTTK}, {"printf", tokenType::PRINTFTK},
        {"return", tokenType::RETURNTK}, {"void", tokenType::VOIDTK}
};

class tokenNode{
    public:
        tokenType tk;
        string content;
        int line;
        tokenNode(){

        }
        tokenNode(tokenType tk, string content,int line){
            this->tk = tk;
            this->content = content;
            this->line = line;
        }
};
class symbolNode { // 符号表中的每一行
    private:
        string name;
        /*
          update : 加入#id 使得id表示当前变量所属的block 编号
        */
        symbolTableKind kind;
        symbolTableType type;
        int blockid;
        friend class symbolTree;
    public:
        vector<symbolTableType> funcParam;
        symbolTableType getType(){
            return type;
        }
        symbolTableKind getKind(){
            return kind;
        }
        symbolNode(string name, symbolTableKind kind,  symbolTableType type,int blockid){
            this->name = name;
            this->kind = kind;
            this->type = type;
            this->blockid = blockid;
        }

        string getName(){
            return name;
        }
};
int blockIdNum = 0;
class subprogramNode { // 整棵符号表树中的某个节点
    private:
        subprogramNode *father;
        vector<symbolNode*> subprogramTable;
        vector<subprogramNode*> sons;
        friend class symbolTree;
        int blockId;
    public:
        subprogramNode(){
            this->father = nullptr;
            this->blockId = currentBlockid;
        }
        explicit subprogramNode(subprogramNode* fa){
            this->father = fa;
            this->blockId = currentBlockid;
        }
        void init(){
            for(auto child : subprogramTable)
                delete child;
            for(auto child : sons) {
                child->init();
                delete child;
            }
        }
};
class symbolTree {
    private:
        subprogramNode *root, *pointer;
        symbolTree() {root = new subprogramNode(); root->father = nullptr; pointer = root;}
        ~symbolTree() = default;
        symbolTree(const symbolTree&);
        symbolTree& operator=(const symbolTree&);
    public:
        static symbolTree& getInstance() {
            static symbolTree instance;
            return instance;
        }
        void pointerRollBack(){pointer = pointer->father;}
        void addSymbolNode(std::string str, symbolTableKind kind, symbolTableType type,int blockid) {
            auto node = new symbolNode(std::move(str), kind, type,blockid);
            pointer->subprogramTable.emplace_back(node);
        }

        void addFuncParam(std::string str, symbolTableType type,int blockid) {
            subprogramNode *fa = pointer->father;
            symbolNode *func = *fa->subprogramTable.rbegin();
            func->funcParam.emplace_back(type);
            addSymbolNode(std::move(str), symbolTableKind::Param, type,blockid);
        }
        checkStatus searchSingleBlockIdent(const string& name){
            // Look for whether the Ident has appeared in the current block.
            for(auto sh : pointer->subprogramTable)
                if(sh->getName() == name)
                    return checkStatus::Redefine;
            return checkStatus::Undefined;
        }
        
        checkStatus searchIdent(const string& name)  {
            subprogramNode *ptr = pointer;
            while(ptr != nullptr) {
                for(auto sh : ptr->subprogramTable)
                    if(sh->getName() == name) {
                        return checkStatus::Correct;
                    }
                ptr = ptr->father;
            }
            return checkStatus::Undefined;
        }
        int searchBlockid(const string& name) {
            subprogramNode *ptr = pointer;
            while(ptr != nullptr) {
                for(auto sh : ptr->subprogramTable)
                    if(sh->getName() == name) {
                        return sh->blockid;
                    }
                ptr = ptr->father;
            }
            assert(1<0);
            return 0;
        }
        symbolNode *askIdent(const string& name){
            subprogramNode *ptr = pointer;
            while(ptr != nullptr) {
                for (auto sh: ptr->subprogramTable)
                    if (sh->getName() == name)
                        return sh;
                ptr = ptr->father;
            }
            return new symbolNode("nothing", NoneKind, NoneType,0);
        }
        void addSubprogram() {
            auto *son = new subprogramNode(pointer);
            pointer->sons.emplace_back(son);
            pointer = son;
        }
        checkStatus checkFunctionParams(const std::string &str,const std::vector<symbolTableType> &list) {
            subprogramNode *rt = root;
            for(auto child : rt->subprogramTable)
                if(child->getName() == str) {
                    if(list.size() != child->funcParam.size())
                        return ParamNumberMismatch;
                    int len = (int)list.size();
                    for(int i = 0; i < len; i++)
                        if(list[i] != child->funcParam[i])
                            return ParamTypeMismatch;
                }
            return Correct;
        }
};

symbolTableType lowerDim(symbolTableType a){
    if(a==Array2) return Array1;else return Int;
}

class Lexer {
    protected:
        string context;
        int line, len, pos;
        void rollBack() {pos--; }
        bool singleOp(char sh){
            char next;
            switch (sh) {
                case '!':
                    next = getSym();
                    if(next == '=')
                        Result.emplace_back(tokenType::NEQ, "!=",line);
                    else {
                        rollBack();
                        Result.emplace_back(tokenType::NOT, "!",line);
                    }
                    break;
                case '+':
                    Result.emplace_back(tokenType::PLUS, "+",line);
                    break;
                case '-':
                    Result.emplace_back(tokenType::MINU, "-",line);
                    break;
                case '*':
                    Result.emplace_back(tokenType::MULT, "*",line);
                    break;

                case '/':
                // 注释
                    next = getSym();
                    if(next == '/') {  
                        while(next != '\n') next = getSym();
                        line++;
                    } else if(next == '*') {
                        int end = 0;  
                        while(end != 2) {
                            next = getSym();
                            if(next == '*') end = 1;
                            else if(end == 1 && next == '/') end++;
                            else { end = 0; line += (next == '\n'); }
                        }
                    }
                    else {
                        rollBack();
                        Result.emplace_back(tokenType::DIV, "/",line);
                    }
                    break;

                case '%':
                    Result.emplace_back(tokenType::MOD, "%",line);
                    break;
                case '<':
                    next = getSym();
                    if(next == '=')
                        Result.emplace_back(tokenType::LEQ, "<=",line);
                    else {
                        rollBack();
                        Result.emplace_back(tokenType::LSS, "<",line);
                    }
                    break;
                case '>':
                    next = getSym();
                    if(next == '=')
                        Result.emplace_back(tokenType::GEQ, ">=",line);
                    else {
                        rollBack();
                        Result.emplace_back(tokenType::GRE, ">",line);
                    }
                    break;
                case '=':
                    next = getSym();
                    if(next == '=')
                        Result.emplace_back(tokenType::EQL, "==",line);
                    else {
                        rollBack();
                        Result.emplace_back(tokenType::ASSIGN, "=",line);
                    }
                    break;
                case ';':
                    Result.emplace_back(tokenType::SEMICN, ";",line);
                    break;
                case ',':
                    Result.emplace_back(tokenType::COMMA, ",",line);
                    break;
                case '(':
                    Result.emplace_back(tokenType::LPARENT, "(",line);
                    break;
                case ')':
                    Result.emplace_back(tokenType::RPARENT, ")",line);
                    break;
                case '[':
                    Result.emplace_back(tokenType::LBRACK, "[",line);
                    break;
                case ']':
                    Result.emplace_back(tokenType::RBRACK, "]",line);
                    break;
                case '{':
                    Result.emplace_back(tokenType::LBRACE, "{",line);
                    break;
                case '}':
                    Result.emplace_back(tokenType::RBRACE, "}",line);
                    break;
                case '|':
                    next = getSym();
                    if(next == '|')
                        Result.emplace_back(tokenType::OR, "||",line);
                    break;
                case '&':
                    next = getSym();
                    if(next == '&')
                        Result.emplace_back(tokenType::AND, "&&",line);
                    break;
                default:
                    return false;
            }
            return true;
        }
        bool keywords(string str){
            for(auto s : keywordsMap)
            if(s.first == str) {
                Result.emplace_back(s.second, str,line);
                return true;
            }
            return false;
        }
        char getSym(){
            if(pos < len) return context[pos++];
            return '\0';
        }
        void getNum(char begin){
            string num(1, begin);
            char next = getSym();
            while(isdigit(next)) {
                num = num+next; 
                next = getSym();
            }
            rollBack();
            Result.emplace_back(tokenType::INTCON, num,line);
        }

    public:
        vector<tokenNode> Result;
        void run(){
            while(pos < len) {
                char ch = getSym();
                if(ch == ' ' || ch == '\r' || ch == '\t') continue;
                if(ch == '\n') {line++; continue;}

                if(singleOp(ch)) continue;
                if(isdigit(ch)) getNum(ch);

                
                else if(isalpha(ch) || ch == '_') {
                    string name(1, ch);
                    ch = getSym();
                    while(isalpha(ch) || isdigit(ch) || ch == '_')
                        {name += ch; ch = getSym();}
                    rollBack();
                    if(!keywords(name))
                        Result.emplace_back(tokenType::IDENFR, name,line);
                }
                else if(ch == '"') {
                    string formatstring(1, ch);
                    ch = getSym();
                    while(ch != '"') {formatstring += ch; ch = getSym();}
                    formatstring += '"';
                    Result.emplace_back(tokenType::STRCON, formatstring,line);
                }
            }
        }

        explicit Lexer(string str) {
            context = move(str);
            line = 1;  pos = 0;
            len = context.length();
            Result.clear();
        }
};

struct tree{
    bool isLeaf;
    int father,depth;
    vector<int> children;
    tokenType tk;
    GrammarItem gi;
    string tkContent;
    int line;//表示终结符号在原文中的行号
    int blockid;
}Tree[100005];
symbolTableType setVarDim(int num) {
    if(num == 0) return symbolTableType::Int;
    if(num == 1) return symbolTableType::Array1;
    return symbolTableType::Array2;
}
static checkStatus checkFormatstring(const std::string &name, int &askNum) {
    int len = (int)name.length();   askNum = 0;
    bool flag = true;
    for(int i = 1; i < len - 1; i++) {
        if(name[i] == 32 || name[i] == 33 || (name[i] >=40 && name[i] <= 126))
            if(name[i] != '\\' && name[i] != '%') continue;
        if(name.substr(i, 2) == "\\n") {i++; continue;}
        if(name.substr(i, 2) == "%d") {i++; askNum++; continue;}
        flag = false;
    }
    return flag ? Correct : IllegalSymbols;
}
symbolTableType checkFuncRParam(int p) {//检查P节点（EXP）的变量的格式
    //EXP -> AddExp -> MulExp  -> UnaryExp -> PrimaryExp | Ident  | UnaryOp UnaryExp
    /*
    注意-a 会是
    -a+b
        primaryExp

    */
    
    if(Tree[Tree[p].children[0]].isLeaf) {
        
        if(Tree[Tree[p].children[0]].tk == tokenType::INTCON) return Int;
        if(Tree[Tree[p].children[0]].tk != tokenType::IDENFR)
        {
            return checkFuncRParam(Tree[p].children[1]);
        }     
        symbolTableType first = symbolTree::getInstance().askIdent(Tree[Tree[p].children[0]].tkContent)->getType();
        for(auto son : Tree[p].children)
            if(Tree[son].isLeaf && Tree[son].tk == tokenType::LBRACK)
                first = lowerDim(first);
        return first;
    }

    if(Tree[Tree[p].children[0]].gi == GrammarItem::UnaryOp)  return checkFuncRParam(Tree[p].children[1]);else return checkFuncRParam(Tree[p].children[0]);
}

class Parser{
    public:
        vector<tokenNode> lexerResult;
        int getLastLine(){
            return lexerResult[pos-1].line;
        }
        Parser(vector<tokenNode> temp){
            treeNum = 0;
            pos = 0;
            lexerResult = temp;
        }
        int run(){
            int root = dfs_CompUnit(1);
            return root;
        }
        
        void makeTree(int num,GrammarItem gi,int depth){
            Tree[num].gi = gi;
            Tree[num].depth = depth;
            Tree[num].tk = tokenType::UNKNOWN;
        }
        
        void makeLeaf(int num,tokenType tk,int depth,int father,string tkContent,int line){
            Tree[num].depth = depth;
            Tree[num].tk = tk;
            Tree[num].father = father;
            Tree[num].isLeaf = true;
            Tree[num].tkContent = tkContent;
            Tree[father].children.push_back(num);
            Tree[num].line = line;
            Tree[num].gi = GrammarItem::UNKNOWN;
            pos++;
        }
        
        int dfs_CompUnit(int depth){
            

            int root = ++treeNum;
            Tree[root].gi = GrammarItem:: CompUnit;
            Tree[root].depth = depth;
            Tree[root].tk = tokenType::UNKNOWN;
            //Decl
            while(this->lexerResult[pos+2].tk != tokenType::LPARENT){
                int child = ++treeNum;
                Tree[root].children.push_back(child);
                Tree[child].father = root;
                dfs_Decl(depth+1);
            }
            //FuncDef
            while(this->lexerResult[pos+1].tk != tokenType::MAINTK){
                int child = ++treeNum;
                Tree[root].children.push_back(child);
                Tree[child].father = root;
                dfs_FuncDef(depth+1);
            }
            //MainFucDef
            int child = ++treeNum;
            Tree[root].children.push_back(child);
            Tree[child].father = root;
            dfs_MainFuncDef(depth+1);
            return root;
        }
        
        int dfs_Decl(int depth){
            int decl = treeNum;
            Tree[decl].gi = GrammarItem::Decl;
            Tree[decl].depth = depth;
            Tree[decl].tk = tokenType::UNKNOWN;

            //const Decl
            if(this->lexerResult[pos].tk == tokenType::CONSTTK){
                int child = ++treeNum;
                Tree[decl].children.push_back(child);
                Tree[child].father = decl;
                dfs_ConstDecl(depth+1);
                return decl;
            } 
            //val Decl
            int child = ++treeNum;
            Tree[decl].children.push_back(child);
            Tree[child].father = decl;
            dfs_VarDecl(depth+1);
            return decl;
        }
        
        int dfs_FuncDef(int depth){
            
            int funcDef = treeNum;
            Tree[funcDef].gi = GrammarItem::FuncDef;
            Tree[funcDef].depth = depth;
            Tree[funcDef].tk = tokenType::UNKNOWN;
            // FuncType
            int child = ++treeNum;
            Tree[funcDef].children.push_back(child);
            Tree[child].father = funcDef;
            dfs_FuncType(depth+1);
            

            symbolTableType type = (getLastLeaf(child).tk == tokenType::INTTK) ?
            symbolTableType::Int : symbolTableType::Void;
            // Ident
            child = ++treeNum;
            Tree[funcDef].children.push_back(child);
            Tree[child].father = funcDef;
            dfs_Ident(depth+1);

            // add new subprogram block
            std::string name = getLastLeaf(funcDef).tkContent;
            
            if(symbolTree::getInstance().searchSingleBlockIdent(name) == checkStatus::Redefine)
                errorList.emplace_back(getLastLeaf(funcDef).line, checkStatus::Redefine);  // errorCode : b
            symbolTree::getInstance().addSymbolNode(name, symbolTableKind::Function, type, 0);
            symbolTree::getInstance().addSubprogram();
            // '('
            assert(lexerResult[pos].tk == tokenType::LPARENT);
            child = ++treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,funcDef,lexerResult[pos].content,lexerResult[pos].line);
            
            // FuncParams
            if(lexerResult[pos].tk == tokenType::INTTK){
                child = ++treeNum;
                Tree[funcDef].children.push_back(child);
                Tree[child].father = funcDef;
                dfs_FuncFParams(depth+1);
            }
            // ')'

            if(lexerResult[pos].tk == tokenType::RPARENT){

                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,funcDef,lexerResult[pos].content,lexerResult[pos].line);
            }else errorList.emplace_back(getLastLine(), checkStatus::RPARENTLack); // errorCode : j
            //Block
            child = ++treeNum;
            Tree[child].father = funcDef;
            Tree[funcDef].children.push_back(child);
            dfs_Block(depth+1);
            //check return 
            /*
                block
                    {
                    blockItem
                    }
                    {
                    blockItem
                    }
                    {
                    blockItem
                        stmt
                            return 
                    }
            */
            if(type == Int){
                int sz = Tree[child].children.size();
                int nd = Tree[child].children[sz-2];//last one blockItem
                
                int line = Tree[Tree[child].children[sz-1]].line;
                if(Tree[nd].isLeaf) errorList.emplace_back(line, ReturnLack);
                else{
                    nd = Tree[Tree[nd].children[0]].children[0];
                    if(!Tree[nd].isLeaf || Tree[nd].tkContent!="return")
                        errorList.emplace_back(line,ReturnLack); 
                }
            }
            symbolTree::getInstance().pointerRollBack();
            return funcDef;
        }
        
        int dfs_MainFuncDef(int depth) {
            /* MainFuncDef → 'int' 'main' '(' ')' Block */
            int mainFuncDef = treeNum;
            makeTree(mainFuncDef,GrammarItem::MainFuncDef,depth);
            int child;
            // 'int'
            assert(lexerResult[pos].tk == tokenType::INTTK);
            child = ++treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,mainFuncDef,lexerResult[pos].content,lexerResult[pos].line);
            // 'main'
            assert(lexerResult[pos].tk == tokenType::MAINTK);
            child = ++treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,mainFuncDef,lexerResult[pos].content,lexerResult[pos].line);
            // '('
            assert(lexerResult[pos].tk == tokenType::LPARENT);
            child = ++treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,mainFuncDef,lexerResult[pos].content,lexerResult[pos].line);
            // ')'
            if(lexerResult[pos].tk == tokenType::RPARENT){
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,mainFuncDef,lexerResult[pos].content,lexerResult[pos].line);
            }else errorList.emplace_back(getLastLeaf(mainFuncDef).line,RPARENTLack);
            // Block
            
            symbolTree::getInstance().addSubprogram();
            
            child = ++treeNum;
            Tree[child].father = mainFuncDef;
            Tree[mainFuncDef].children.push_back(child);
            this->dfs_Block(depth + 1);
            symbolTree::getInstance().pointerRollBack();

            // check return
            int sz = Tree[child].children.size();
            int nd = Tree[child].children[sz-2];//last one block 
            int line = Tree[Tree[child].children[sz-1]].line;
            if(Tree[nd].isLeaf) errorList.emplace_back(line, ReturnLack);
            else{
                nd = Tree[Tree[nd].children[0]].children[0];
                if(!Tree[nd].isLeaf || Tree[nd].tkContent!="return")
                    errorList.emplace_back(line,ReturnLack); 
            }
            return mainFuncDef;
        }
        
        int dfs_ConstDecl(int depth){
            int constDecl = treeNum;
            Tree[constDecl].gi = GrammarItem::ConstDecl;
            Tree[constDecl].depth = depth;
            Tree[constDecl].tk = tokenType::UNKNOWN;
            //CONSTTAG
            assert(lexerResult[pos].tk == tokenType::CONSTTK);

            int child = ++treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,constDecl,lexerResult[pos].content,lexerResult[pos].line);
            //BTYPE
            child = ++treeNum;
            Tree[child].father = constDecl;
            Tree[constDecl].children.push_back(child);
            dfs_BTYPE(depth+1);
            //ConstDef
            child = ++treeNum;
            Tree[child].father = constDecl;
            Tree[constDecl].children.push_back(child);
            dfs_ConstDef(depth+1);
            // ConstDef Repeat
            while(lexerResult[pos].tk==tokenType::COMMA) {
                //COMMA
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,constDecl,lexerResult[pos].content,lexerResult[pos].line);

                //ConstDef 
                child = ++treeNum;
                Tree[child].father = constDecl;
                Tree[constDecl].children.push_back(child);
                dfs_ConstDef(depth+1);
            }
            //;
            if(lexerResult[pos].tk==tokenType::SEMICN){
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,constDecl,lexerResult[pos].content,lexerResult[pos].line);
            }else errorList.emplace_back(getLastLine(),checkStatus::SEMICNLack);
            return constDecl;
        }
        
        int dfs_VarDecl(int depth){
            int varDecl = treeNum;
            makeTree(varDecl,GrammarItem::VarDecl,depth);   
            //BTYPE
            int child = ++treeNum;
            Tree[child].father = varDecl;
            Tree[varDecl].children.push_back(child);
            dfs_BTYPE(depth+1);
            // VarDef
            child = ++treeNum;
            Tree[child].father = varDecl;
            Tree[varDecl].children.push_back(child);
            dfs_VarDef(depth+1);
            // VarDef Repeat
            while(lexerResult[pos].tk == tokenType::COMMA){
                child = ++treeNum;
                makeLeaf(child,tokenType::COMMA,depth+1,varDecl,lexerResult[pos].content,lexerResult[pos].line);
                child = ++treeNum;
                Tree[child].father = varDecl;
                Tree[varDecl].children.push_back(child);
                dfs_VarDef(depth+1);
            }
            //";"
            if(lexerResult[pos].tk == tokenType::SEMICN){
                child = ++treeNum;
                makeLeaf(child,tokenType::SEMICN,depth+1,varDecl,lexerResult[pos].content,lexerResult[pos].line);
            }else errorList.emplace_back(getLastLine(),checkStatus::SEMICNLack);
            return varDecl;
        }
        
        int dfs_BTYPE(int depth){
            int Btype = treeNum;
            makeTree(Btype,GrammarItem::BType,depth);
            assert(lexerResult[pos].tk == tokenType::INTTK);
            int child = ++treeNum;
            makeLeaf(child,tokenType::INTTK,depth+1,Btype,lexerResult[pos].content,lexerResult[pos].line);
            return Btype;
        }
        tree getLastLeaf(int p){
            int sz = Tree[p].children.size();
            return Tree[Tree[p].children[sz-1]];
        }
        int dfs_ConstDef(int depth){
            int constDef = treeNum;
            makeTree(constDef,GrammarItem::ConstDef,depth);
            //Ident
            
            
            int child = ++treeNum;
            Tree[child].father = constDef;
            Tree[constDef].children.push_back(child);
            dfs_Ident(depth+1);

            string name = getLastLeaf(constDef).tkContent;
            if(symbolTree::getInstance().searchSingleBlockIdent(name) == Redefine)
                errorList.emplace_back(getLastLeaf(constDef).line,Redefine);
            // '['
            int arrayDim = 0;
            while(lexerResult[pos].tk == tokenType::LBRACK){
                child = ++treeNum;
                makeLeaf(child,tokenType::LBRACK,depth+1,constDef,lexerResult[pos].content,lexerResult[pos].line);
                // constExp
                child = ++treeNum;
                Tree[constDef].children.push_back(child);
                Tree[child].father = constDef;
                dfs_ConstExp(depth+1);
                // ']'
                if(lexerResult[pos].tk == tokenType::RBRACK){
                    child = ++treeNum;
                    makeLeaf(child,tokenType::RBRACK,depth+1,constDef,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(), RBRACKLack); 
                arrayDim ++;
            }

            checkStatus status = symbolTree::getInstance().searchSingleBlockIdent(name);
            if(status == checkStatus::Undefined)
                symbolTree::getInstance().addSymbolNode(name, symbolTableKind::Const, setVarDim(arrayDim),currentBlockid);
            else errorList.emplace_back(getLastLeaf(constDef).line, status);    // errorCode : b
            // '='

            assert(lexerResult[pos].tk == tokenType::ASSIGN);
            child = ++treeNum;;
            makeLeaf(child,tokenType::ASSIGN,depth+1,constDef,lexerResult[pos].content,lexerResult[pos].line);

            // constInitval
            child = ++treeNum;
            Tree[constDef].children.push_back(child);
            Tree[child].father = constDef;
            dfs_ConstInitVal(depth+1);
            return constDef;
        }
        
        int dfs_Ident(int depth){
            /*
                考虑其父节点的grammarItem，

            */
            assert(lexerResult[pos].tk == tokenType::IDENFR);
            int child = treeNum;
            Tree[child].isLeaf = true;
            Tree[child].tk = tokenType::IDENFR;
            Tree[child].tkContent = lexerResult[pos].content;
            Tree[child].line = lexerResult[pos].line;
            string name = lexerResult[pos].content;
            
                if(Tree[Tree[child].father].gi == GrammarItem::FuncDef || Tree[Tree[child].father].gi == GrammarItem::VarDef || Tree[Tree[child].father].gi == GrammarItem::ConstDef || Tree[Tree[child].father].gi == GrammarItem::FuncFParam) {
                    // 如果未定义，则此时是定义时
                    //cout<<grammarItem2string[Tree[Tree[child].father].gi]<<endl;
                    if(Tree[Tree[child].father].gi == GrammarItem::FuncDef)Tree[child].blockid = 0;else 
                    Tree[child].blockid = currentBlockid;
                    //cout<<Tree[child].tkContent<<" "<<Tree[child].blockid<<endl;
                }else{
                    int bi = symbolTree::getInstance().searchBlockid(name);
                    Tree[child].blockid = bi;
                }




            pos++;
            return child;
        }
        
        int dfs_ConstExp(int depth){
            int constExp = treeNum;
            makeTree(constExp,GrammarItem::ConstExp,depth);
            
            int child = dfs_AddExp(depth+1);
            Tree[child].father = constExp;
            Tree[constExp].children.push_back(child);
            

            return constExp;
        }
        
        int dfs_ConstInitVal(int depth){
            int constInitVal = treeNum;
            makeTree(constInitVal,GrammarItem::ConstInitVal,depth);
            //ConstExp
            if(lexerResult[pos].tk != tokenType::LBRACE){
                int child = ++treeNum;
                Tree[child].father = constInitVal;
                Tree[constInitVal].children.push_back(child);
                dfs_ConstExp(depth+1);
            }else{ // '{' [ ConstInitVal { ',' ConstInitVal } ] '}'
                int child = ++treeNum;
                makeLeaf(child,tokenType::LBRACE,depth+1,constInitVal,lexerResult[pos].content,lexerResult[pos].line);
                if(lexerResult[pos].tk != tokenType::RBRACE){
                    child = ++treeNum;
                    Tree[child].father = constInitVal;
                    Tree[constInitVal].children.push_back(child);
                    dfs_ConstInitVal(depth+1);
                    // { ',' ConstInitVal }
                    while(lexerResult[pos].tk == tokenType::COMMA){
                        child = ++treeNum;
                        makeLeaf(child,tokenType::COMMA,depth+1,constInitVal,lexerResult[pos].content,lexerResult[pos].line);
                        
                        child = ++treeNum;
                        Tree[child].father = constInitVal;
                        Tree[constInitVal].children.push_back(child);
                        dfs_ConstInitVal(depth+1);
                    }

                }
                assert(lexerResult[pos].tk == tokenType::RBRACE);
                child = ++treeNum;
                makeLeaf(child,tokenType::RBRACE,depth+1,constInitVal,lexerResult[pos].content,lexerResult[pos].line);
            }
            return constInitVal;
        }
        
        int dfs_VarDef(int depth){
            /* VarDef → Ident { '[' ConstExp ']' }  |  Ident { '[' ConstExp ']' } '=' InitVal */
            int varDef = treeNum;
            
            makeTree(varDef,GrammarItem::VarDef,depth);
            //Ident
            int child = ++treeNum;
            Tree[child].father = varDef;
            Tree[varDef].children.push_back(child);
            dfs_Ident(depth+1);

            string name = getLastLeaf(varDef).tkContent;
            if(symbolTree::getInstance().searchSingleBlockIdent(name) == Redefine)
                errorList.emplace_back(getLastLeaf(varDef).line, Redefine); // errorCode : b
            // { '[' ConstExp ']' }
            int varDim = 0;
            while(lexerResult[pos].tk == tokenType::LBRACK){
                child = ++treeNum;
                makeLeaf(child,tokenType::LBRACK,depth+1,varDef,lexerResult[pos].content,lexerResult[pos].line);

                child = ++treeNum;
                Tree[varDef].children.push_back(child);
                Tree[child].father = varDef;

                dfs_ConstExp(depth+1);

                if(lexerResult[pos].tk==tokenType::RBRACK){
                    child = ++treeNum;
                    makeLeaf(child,tokenType::RBRACK,depth+1,varDef,lexerResult[pos].content,lexerResult[pos].line);
                }else    errorList.emplace_back(getLastLine(), checkStatus::RBRACKLack);  
                varDim++;
            }
            symbolTree::getInstance().addSymbolNode(name, Var, setVarDim(varDim),currentBlockid);
            if(lexerResult[pos].tk == tokenType::ASSIGN){ //"="
                child = ++treeNum;
                makeLeaf(child,tokenType::ASSIGN,depth+1,varDef,lexerResult[pos].content,lexerResult[pos].line);

                child = ++treeNum;
                Tree[varDef].children.push_back(child);
                Tree[child].father = varDef;
                dfs_InitVal(depth+1);
            }
            
            return varDef;
        }
        
        int dfs_InitVal(int depth){
            /* InitVal → Exp | '{' [ InitVal { ',' InitVal } ] '}' */
            int child = 0;
            int initVal = treeNum;

            int temp = initVal;
            makeTree(initVal,GrammarItem::InitVal,depth);
            if(lexerResult[pos].tk == tokenType::LBRACE){
                child = ++treeNum;
                makeLeaf(child,tokenType::LBRACE,depth+1,initVal,lexerResult[pos].content,lexerResult[pos].line);

                if(lexerResult[pos].tk != tokenType::RBRACE){
                    child = ++treeNum;
                    Tree[child].father = initVal;
                    Tree[initVal].children.push_back(child);
                    dfs_InitVal(depth+1);

                    // { ',' InitVal }
                    while(lexerResult[pos].tk == tokenType::COMMA){
                        child = ++treeNum;
                        makeLeaf(child,tokenType::COMMA,depth+1,initVal,lexerResult[pos].content,lexerResult[pos].line);
                        child = ++treeNum;
                        Tree[child].father = initVal;
                        Tree[initVal].children.push_back(child);
                        dfs_InitVal(depth+1);
                    }
                }
                // }
                child = ++treeNum;
                makeLeaf(child,tokenType::RBRACE,depth+1,initVal,lexerResult[pos].content,lexerResult[pos].line);
            }   else{
                //Exp

                child = ++treeNum;
                Tree[child].father = initVal;
                Tree[initVal].children.push_back(child);
                dfs_Exp(depth+1);
            }
            return initVal;
        }
        
        int dfs_Exp(int depth){
            int exp =  treeNum;
            
            makeTree(exp,GrammarItem::Exp,depth);

            int child = dfs_AddExp(depth+1);
            Tree[child].father = exp;
            Tree[exp].children.push_back(child);
            return exp;
        }
        
        int dfs_FuncType(int depth){
            int funcType = treeNum;
            makeTree(funcType,GrammarItem::FuncType,depth);
            assert(lexerResult[pos].tk == tokenType::VOIDTK || lexerResult[pos].tk == tokenType::INTTK);
            int child = ++ treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,funcType,lexerResult[pos].content,lexerResult[pos].line);
            return funcType;
        }
        
        int dfs_FuncFParams(int depth) {
            currentBlockid ++;//进入下一个块
            /* FuncFParams → FuncFParam { ',' FuncFParam } */
            int funcFParams = treeNum;
            makeTree(funcFParams,GrammarItem::FuncFParams,depth);
            
            // FuncFParam
            int child = ++treeNum;
            Tree[child].father = (funcFParams);
            Tree[funcFParams].children.push_back(child);
            dfs_FuncFParam(depth + 1);
            // { ',' FuncFParam }
            while (lexerResult[pos].tk == tokenType::COMMA) {
                // ','
                
                int child = ++treeNum;
                makeLeaf(child,tokenType::COMMA,depth +1,funcFParams,lexerResult[pos].content,lexerResult[pos].line);
                // FuncFParam
                child = ++treeNum;
                Tree[child].father = (funcFParams);
                Tree[funcFParams].children.push_back(child);
                child = dfs_FuncFParam(depth + 1);
            }
            currentBlockid --;
            return funcFParams;
        }
        
        int dfs_Block(int depth) {
            /* Block → '{' { BlockItem } '}' */
            int block = treeNum;
            currentBlockid++;
            makeTree(block,GrammarItem::Block,depth);
            
            // '{'
            assert(lexerResult[pos].tk == tokenType::LBRACE);
            int child = ++treeNum;
            makeLeaf(child,tokenType::LBRACE,depth +1,block,lexerResult[pos].content,lexerResult[pos].line);
            // { BlockItem }
            while (lexerResult[pos].tk != tokenType::RBRACE) {
                child = ++treeNum;
                Tree[child].father = (block);
                Tree[block].children.push_back(child);
                dfs_BlockItem(depth + 1);
            }
            // '}'
            child = ++treeNum;
            makeLeaf(child,tokenType::RBRACE,depth+1,block,lexerResult[pos].content,lexerResult[pos].line);
            //确保在一个block里定义的都应该一样
            //currentBlockid --;
            return block;
        }
     
        int dfs_FuncFParam(int depth) {
            /* FuncFParam → BType Ident ['[' ']' { '[' ConstExp ']' }] */
            int funcFParam = treeNum;
            makeTree(funcFParam,GrammarItem::FuncFParam,depth);
            
            // BType
            int child = ++treeNum;
            Tree[child].father = (funcFParam);
            Tree[funcFParam].children.push_back(child);
            dfs_BTYPE(depth + 1);
            // Ident
            child = ++treeNum;
            Tree[child].father = (funcFParam);
            Tree[funcFParam].children.push_back(child);
            dfs_Ident(depth + 1);

            string name = getLastLeaf(funcFParam).tkContent;
            checkStatus status = symbolTree::getInstance().searchSingleBlockIdent(name);
            if(status == Redefine)
                errorList.emplace_back(getLastLeaf(funcFParam).line, status); // errorCode : b
            // ['[' ']' { '[' ConstExp ']' }]
            int arrayDim = 0;
            if (lexerResult[pos].tk == tokenType::LBRACK) {
                // '['
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,funcFParam,lexerResult[pos].content,lexerResult[pos].line);
                // ']'
                if(lexerResult[pos].tk == tokenType::RBRACK){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,funcFParam,lexerResult[pos].content,lexerResult[pos].line);
                }else{
                    errorList.emplace_back(getLastLine(),RBRACKLack);
                }    
                arrayDim++;
                while (lexerResult[pos].tk == tokenType::LBRACK) {
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,funcFParam,lexerResult[pos].content,lexerResult[pos].line);
                    // ConstExp
                    child = ++treeNum;
                    Tree[child].father = (funcFParam);
                    Tree[funcFParam].children.push_back(child);
                    dfs_ConstExp(depth + 1);
                    // ']'
                    if(lexerResult[pos].tk == tokenType::RBRACK){
                        child = ++treeNum;
                        makeLeaf(child,lexerResult[pos].tk,depth+1,funcFParam,lexerResult[pos].content,lexerResult[pos].line);
                    }else errorList.emplace_back(getLastLine(),RBRACKLack);    
                    arrayDim++;
                }
            }
            symbolTree::getInstance().addFuncParam(name, setVarDim(arrayDim),currentBlockid);
            return funcFParam;
        }
      
        int dfs_BlockItem(int depth) {
            /* BlockItem → Decl | Stmt */
            int blockItem = treeNum;
            makeTree(blockItem,GrammarItem::BlockItem,depth);
            int child;
            // Decl → ConstDecl | VarDecl, 以 const 或 int 开头
            if (lexerResult[pos].tk == tokenType::CONSTTK || lexerResult[pos].tk == tokenType::INTTK) {
                
                child = ++treeNum;
                Tree[child].father = (blockItem);
                Tree[blockItem].children.push_back(child);
                
                
                dfs_Decl(depth + 1);
            } else {
                child = ++treeNum;
                Tree[child].father = (blockItem);
                Tree[blockItem].children.push_back(child);
                
                dfs_Stmt(depth + 1);
                
            }
            
            return blockItem;
        }
        int hasAssignInCurrentLine(){
            int p = pos;
            int flag = 0;
            for(int i = pos+1;i<lexerResult.size();i++)
            {
                if(lexerResult[i].line > lexerResult[p].line) break;
                if(lexerResult[i].tk== tokenType::ASSIGN) return 1;
            }
            return 0;
        }
        int dfs_Stmt(int depth) {
            int stmt = treeNum;
            makeTree(stmt,GrammarItem::Stmt,depth);

            if (lexerResult[pos].tk == tokenType::PRINTFTK) {  /* 'printf''('Formatstring{','Exp}')'';' */
                int child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                int printLine = getLastLeaf(stmt).line;
                // '('

                assert(lexerResult[pos].tk == tokenType::LPARENT);
                
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                // Formatstring
                child = ++treeNum;
                Tree[child].father = (stmt);
                Tree[stmt].children.push_back(child);
                dfs_Formatstring(depth + 1);

                int askNum = 0;
                string str = getLastLeaf(stmt).tkContent;
                
                checkStatus status = checkFormatstring(str, askNum);
                if(status != Correct)
                    errorList.emplace_back(getLastLeaf(stmt).line, status); 

                // {','Exp}
                int expNum = 0;
                while (lexerResult[pos].tk == tokenType::COMMA) {
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                    
                    // Exp
                    child = ++treeNum;
                    Tree[child].father = (stmt);
                    Tree[stmt].children.push_back(child);
                    dfs_Exp(depth + 1);
                    expNum++;
                }
                if(askNum != expNum)
                    errorList.emplace_back(printLine, FormatNumberMismatch); // errorCode : l
                // ')'



                if(lexerResult[pos].tk == tokenType::RPARENT){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(), RPARENTLack);     
                // ';'
                if(lexerResult[pos].tk == tokenType::SEMICN){

                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(), SEMICNLack); // errorCode : i
                
            } else if (lexerResult[pos].tk == tokenType::RETURNTK) {  /* 'return' [Exp] ';' */
                int child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                // [Exp]
                int line = getLastLeaf(stmt).line;
                int hasReturn = 0;
                if (lexerResult[pos].tk != tokenType::SEMICN && lexerResult[pos].line == lexerResult[pos-1].line) {
                    child = ++treeNum;
                    Tree[child].father = (stmt);
                    Tree[stmt].children.push_back(child);
                    this->dfs_Exp(depth + 1);
                    hasReturn = 1;
                }
                int nd = stmt;
                int i = 0;
                while(Tree[nd].gi != GrammarItem::FuncDef && Tree[nd].gi != GrammarItem::MainFuncDef){
                    
                    nd = Tree[nd].father;
                    //cout<<grammarItem2string[Tree[nd].gi]<<endl;
                    
                }

                if(Tree[Tree[nd].children[0]].gi == GrammarItem::FuncType){
                    tokenType tp = Tree[Tree[Tree[nd].children[0]].children[0]].tk;
                    if(tp == tokenType::INTTK && !hasReturn)
                        errorList.emplace_back(line, ReturnMismatch);   // errorCode : f
                    if(tp == tokenType::VOIDTK && hasReturn)
                        errorList.emplace_back(line, ReturnMismatch);
                }else if(!hasReturn)        // 'int' 'main' '(' ')' Stmt
                errorList.emplace_back(line, ReturnMismatch);
                
                // ';'
                if(lexerResult[pos].tk == tokenType::SEMICN){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(),SEMICNLack);    
            } else if (lexerResult[pos].tk == tokenType::IFTK) {  /* 'if' '(' Cond ')' Stmt [ 'else' Stmt ] */
                int child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                // '('
                assert(lexerResult[pos].tk == tokenType::LPARENT);
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                // Cond
                child = ++treeNum;
                Tree[child].father = (stmt);
                Tree[stmt].children.push_back(child);
                dfs_Cond(depth + 1);
                // ')'
                if(lexerResult[pos].tk == tokenType::RPARENT){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else  errorList.emplace_back(getLastLine(), RPARENTLack); // errorCode : j
        // Stmt   
                // Stmt
                child = ++treeNum;
                Tree[child].father = (stmt);
                Tree[stmt].children.push_back(child);
                dfs_Stmt(depth + 1);
                // [ 'else' Stmt ]
                if (lexerResult[pos].tk == tokenType::ELSETK) {
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                    // Stmt
                    child = ++treeNum;
                    Tree[child].father = (stmt);
                    Tree[stmt].children.push_back(child);
                    dfs_Stmt(depth + 1);
                }
            } else if(lexerResult[pos].tk == tokenType::FORTK){
                //'for' '(' [ForStmt] ';' [Cond] ';' [ForStmt] ')' Stmt // 1. 无缺省 2. 缺省第一个ForStmt 3. 缺省Cond 4. 缺省第二个ForStmt
                int child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);

                assert(lexerResult[pos].tk == tokenType::LPARENT);
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);

                if(lexerResult[pos].tk != tokenType::SEMICN){
                    child = ++treeNum;
                    Tree[stmt].children.push_back(child);
                    Tree[child].father = stmt;
                    dfs_ForStmt(depth+1);
                }

                assert(lexerResult[pos].tk == tokenType::SEMICN);
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);

                if(lexerResult[pos].tk != tokenType::SEMICN){
                    child = ++treeNum;
                    Tree[stmt].children.push_back(child);
                    Tree[child].father = stmt;
                    dfs_Cond(depth+1);
                }

                assert(lexerResult[pos].tk == tokenType::SEMICN);
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);

                if(lexerResult[pos].tk == tokenType::IDENFR){
                    child = ++treeNum;
                    Tree[stmt].children.push_back(child);
                    Tree[child].father = stmt;
                    dfs_ForStmt(depth+1);
                }

                if(lexerResult[pos].tk == tokenType::RPARENT){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(),RPARENTLack);
                child = ++treeNum;
                Tree[stmt].children.push_back(child);
                Tree[child].father = stmt;
                dfs_Stmt(depth+1);
            }else if(lexerResult[pos].tk == tokenType::BREAKTK || lexerResult[pos].tk == tokenType::CONTINUETK){
                int child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                //判断是否在非循环节中使用了break或continue
                /*
                block
                    stmt 
                        for(;;) stmt
                                block



                    block
                        blockitem
                            stmt
                                for
                */
                int fa = Tree[stmt].father;
                int flag = 0;
                //if(Tree[Tree[fa].children[0]].tk == tokenType::FORTK) flag=1;
                //cout<<"begin"<<" ";
                while(!flag){
                    //cout<<fa <<endl;
                    int tt = 1;
                    while (Tree[fa].gi != GrammarItem::Block) {
                        
                        if(Tree[fa].gi == GrammarItem::MainFuncDef || Tree[fa].gi == GrammarItem::FuncDef){
                            tt = 0;
                            break;
                        }
                        fa = Tree[fa].father;
                    }
                    if(!tt) break;
                    //cout<<grammarItem2string[Tree[fa].gi]<<endl;
                    //if(Tree[Tree[fa].children[0]].isLeaf) cout<<Tree[Tree[fa].children[0]].tkContent<<endl;
                    // stmt =  for() + stmt = for() + block
                    int SS = Tree[fa].father;
                    //cout<<grammarItem2string[Tree[SS].gi]<<endl;
                    SS = Tree[SS].father;
                    if(Tree[SS].gi == GrammarItem::Stmt && Tree[SS].children.size()>3){
                        //cout<<Tree[SS].children.size()<<endl;
                        if(Tree[Tree[SS].children[0]].tkContent == "for"){
                            flag = 1;
                            break;
                        }
                    }
                    fa = Tree[fa].father;
                }
                //cout<<"endl"<<endl;
                if(!flag)
                    errorList.emplace_back(getLastLeaf(stmt).line, BreakOrContinueMismatch); // errorCode : m
                if(lexerResult[pos].tk == tokenType::SEMICN){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(),SEMICNLack);
            }
            else if (lexerResult[pos].tk == tokenType::LBRACE) {  /* Block */
                int child = ++treeNum;
                Tree[child].father = (stmt);
                Tree[stmt].children.push_back(child);
                symbolTree::getInstance().addSubprogram();
                this->dfs_Block(depth + 1);
                symbolTree::getInstance().pointerRollBack();
            } else if (!hasAssignInCurrentLine()) {  /* 分号比等号先出现: [Exp] ';' */
                if (lexerResult[pos].tk != tokenType::SEMICN) {
                    int child = ++treeNum;
                    Tree[child].father = (stmt);
                    Tree[stmt].children.push_back(child);
                    dfs_Exp(depth + 1);
                }
                //cout<<lexerResult[pos].content<<endl;
                // ';'
                if(lexerResult[pos].tk == tokenType::SEMICN){
                    int child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                }else   errorList.emplace_back(getLastLine(), SEMICNLack);  
            } else {  /* LVal '=' Exp ';'  | LVal '=' 'getint''('')'';' */
                // LVal
                int child = ++treeNum;
                Tree[child].father = (stmt);
                Tree[stmt].children.push_back(child);
                this->dfs_LVal(depth + 1);
                // '='
                string name = Tree[Tree[child].children[0]].tkContent;
                if(symbolTree::getInstance().askIdent(name)->getKind() == Const)
                errorList.emplace_back( Tree[Tree[child].children[0]].line, ModifyConst);
                assert(lexerResult[pos].tk == tokenType::ASSIGN);
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                if (lexerResult[pos].tk != tokenType::GETINTTK) {  // LVal '=' Exp ';'
                    // Exp
                    child = ++treeNum;
                    Tree[child].father = (stmt);
                    Tree[stmt].children.push_back(child);
                    this->dfs_Exp(depth + 1);
                } else {  // LVal '=' 'getint''('')'';'
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                    // '('
                    assert(lexerResult[pos].tk == tokenType::LPARENT);
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                    // ')'
                    if(lexerResult[pos].tk == tokenType::RPARENT){
                        child = ++treeNum;
                        makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                    }else     errorList.emplace_back(getLastLine(), RPARENTLack); // errorCode : j
                }
                // ';'
                
                if(lexerResult[pos].tk == tokenType::SEMICN){
                    child = ++treeNum;
                    makeLeaf(child,lexerResult[pos].tk,depth+1,stmt,lexerResult[pos].content,lexerResult[pos].line);
                } else errorList.emplace_back(getLastLine(), SEMICNLack); // errorCode : i
            }
            return stmt;
        }
        int dfs_ForStmt(int depth){
            int forStmt = treeNum;
            makeTree(forStmt,GrammarItem::ForStmt,depth);

            int child = ++treeNum;
            Tree[forStmt].children.push_back(child);
            Tree[child].father = forStmt;

            dfs_LVal(depth+1);
            assert(lexerResult[pos].tk == tokenType::ASSIGN);
            child = ++ treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,forStmt,lexerResult[pos].content,lexerResult[pos].line);

            child = ++treeNum;
            Tree[forStmt].children.push_back(child);
            Tree[child].father = forStmt;
            dfs_Exp(depth+1);
            return forStmt;
        }
        
        int dfs_Formatstring(int depth) {
            assert(lexerResult[pos].tk == tokenType::STRCON);
           
            int formatstring = treeNum;
            Tree[formatstring].depth = depth;
            Tree[formatstring].isLeaf = true;
            Tree[formatstring].tk = tokenType::STRCON;
            Tree[formatstring].tkContent = lexerResult[pos].content;
            Tree[formatstring].line = lexerResult[pos].line;
            pos++;
            return formatstring;
        }
       
        int dfs_Cond(int depth) {
            /* Cond → LOrExp */
            int cond = treeNum;
            makeTree(cond,GrammarItem::Cond,depth);
            int child = this->dfs_LOrExp(depth + 1);
            Tree[child].father = (cond);
            Tree[cond].children.push_back(child);
            return cond;
        }
        
        bool semicn_before_assign() {
            /* 判断接下来先出现 ';'还是 '=' */
            /* 用于Stmt解析中判断是表达式还是赋值 */
            int i = pos;
            while (lexerResult[i].tk != tokenType::SEMICN &&
                lexerResult[i].tk != tokenType::ASSIGN)
                ++i;
            if (lexerResult[i].tk == tokenType::SEMICN) return true;
            return false;
        }
  
        int dfs_LVal(int depth) {
            /* LVal → Ident {'[' Exp ']'} */
            int lVal = treeNum;
            makeTree(lVal,GrammarItem::LVal,depth);
            int child = ++treeNum;  // Ident
            Tree[child].father = (lVal);
            Tree[lVal].children.push_back(child);
            this->dfs_Ident(depth + 1);

            string name = getLastLeaf(lVal).tkContent;
    
            if(symbolTree::getInstance().searchIdent(name) == Undefined) {
                if(errorList.empty())
                    errorList.emplace_back(getLastLeaf(lVal).line, Undefined); // errorCode : c
                else {
                    auto p= *(errorList.rbegin());
                    auto a = p.first;
                    auto b = p.second;
                    if(a != getLastLeaf(lVal).line || b != Undefined)
                        errorList.emplace_back(getLastLeaf(lVal).line, Undefined); // errorCode : c
                }
            }
            // {'[' Exp ']'}
            while (lexerResult[pos].tk == tokenType::LBRACK) {
                
                child = ++treeNum;
                makeLeaf(child,tokenType::LBRACK,depth + 1,lVal,lexerResult[pos].content,lexerResult[pos].line);
                
                // Exp
                child = ++treeNum;
                Tree[child].father = (lVal);
                Tree[lVal].children.push_back(child);
                this->dfs_Exp(depth + 1);
                // ']'
                if(lexerResult[pos].tk == tokenType::RBRACK){
                
                    child = ++treeNum;
                    makeLeaf(child,tokenType::RBRACK,depth +1,lVal,lexerResult[pos].content,lexerResult[pos].line);
                }else   errorList.emplace_back(getLastLine(), RBRACKLack); 
                
            }
            return lVal;
        }
    
        int dfs_PrimaryExp(int depth) {
            /* PrimaryExp → '(' Exp ')' | LVal | Number */
            
            int primaryExp = treeNum;
            makeTree(primaryExp,GrammarItem::PrimaryExp,depth);
            int child;
            if (lexerResult[pos].tk == tokenType::LPARENT) {  // '(' Exp ')'
                
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,primaryExp,lexerResult[pos].content,lexerResult[pos].line);
                // Exp
                child = ++treeNum;
                Tree[child].father = (primaryExp);
                Tree[primaryExp].children.push_back(child);
                this->dfs_Exp(depth + 1);
                // ')'
                assert(lexerResult[pos].tk == tokenType::RPARENT);
                child = ++treeNum;
                makeLeaf(child,lexerResult[pos].tk,depth+1,primaryExp,lexerResult[pos].content,lexerResult[pos].line);
            } else if (lexerResult[pos].tk == tokenType::IDENFR) {  // LVal  (LVal → Ident {'[' Exp ']'})
                child = ++treeNum;
                Tree[child].father = (primaryExp);
                Tree[primaryExp].children.push_back(child);
                dfs_LVal(depth + 1);
            } else {  // Number
                child = ++treeNum;
                Tree[child].father = (primaryExp);
                Tree[primaryExp].children.push_back(child);
                this->dfs_Number(depth + 1);
            }
            //cout<<"primaryExp::"<<lexerResult[pos].content<<endl;

            return primaryExp;
        }
        
        int dfs_Number(int depth) {
            /* Number → IntConst */
            int number = treeNum;
            makeTree(number,GrammarItem::Number,depth);
            int child = ++treeNum;


            Tree[child].father = (number);
            Tree[number].children.push_back(child);
            dfs_IntConst(depth + 1);
            return number;
        }

        int dfs_IntConst(int depth) {
            cout<<lexerResult[pos].content<<' '<<lexerResult[pos].line<<endl;

            assert(lexerResult[pos].tk == tokenType::INTCON);
            
            int intConst = treeNum;
            Tree[intConst].depth = depth;
            Tree[intConst].tk = tokenType::INTCON;
            Tree[intConst].tkContent = lexerResult[pos].content;
            Tree[intConst].isLeaf = 1;
            pos++;

            return intConst;
        }

        int dfs_UnaryExp(int depth) {
            /* UnaryExp → PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp  */
            int unaryExp = treeNum;
            makeTree(unaryExp,GrammarItem::UnaryExp,depth);
            int child;
            if (lexerResult[pos].tk == tokenType::PLUS
                || lexerResult[pos].tk == tokenType::MINU
                || lexerResult[pos].tk == tokenType::NOT) {  // UnaryOp UnaryExp
                child = ++treeNum;
                Tree[child].father = (unaryExp);
                Tree[unaryExp].children.push_back(child);
                dfs_UnaryOp(depth + 1);
                child = ++treeNum;
                Tree[child].father = (unaryExp);
                Tree[unaryExp].children.push_back(child);
                dfs_UnaryExp(depth + 1);
            } else if (lexerResult[pos].tk == tokenType::IDENFR && lexerResult[pos+1].tk == tokenType::LPARENT) 
            {  // Ident '(' [FuncRParams] ')'
                
                child = ++treeNum;
                Tree[child].father = (unaryExp);
                Tree[unaryExp].children.push_back(child);
                dfs_Ident(depth + 1);
                

                string name = getLastLeaf(unaryExp).tkContent;
                int line = getLastLeaf(unaryExp).line;
                if(symbolTree::getInstance().searchIdent(name) == Undefined)
                    errorList.emplace_back(line, Undefined); // errorCode : c

                // '('
                child = ++treeNum;
                std::vector<symbolTableType> realParams;
                makeLeaf(child,tokenType::LPARENT, depth +1,unaryExp,lexerResult[pos].content,lexerResult[pos].line);
                
                if (lexerResult[pos].tk != tokenType::RPARENT && lexerResult[pos].tk!= tokenType::SEMICN && lexerResult[pos].tk!= tokenType::LBRACK) {  // [FuncRParams]
                    child = ++treeNum;
                    Tree[child].father = (unaryExp);
                    Tree[unaryExp].children.push_back(child);
                    
                    dfs_FuncRParams(depth + 1);
                    //cout<<lexerResult[pos].content<<' '<<lexerResult[pos].line;
                    //FuncRParams ->  EXP , EXP
                    int len = Tree[unaryExp].children.size();
                    for(auto RP:Tree[Tree[unaryExp].children[len-1]].children){
                        
                        if(!Tree[RP].isLeaf) {
                            
                            realParams.emplace_back(checkFuncRParam(RP));
                            

                        }
                    }
                }
                /*
                cout<<name<<endl;
                for(auto x:realParams) cout<<symbolTableType2String((x))<<' ';
                cout<<endl;*/
                checkStatus status = symbolTree::getInstance().checkFunctionParams(name, realParams);
                if(status != Correct)
                    errorList.emplace_back(line, status);   // errorCode : d, e
                        // ')'
                if(lexerResult[pos].tk == tokenType::RPARENT){
                    child = ++treeNum;
                    makeLeaf(child,tokenType::RPARENT, depth +1,unaryExp,lexerResult[pos].content,lexerResult[pos].line);
                }else errorList.emplace_back(getLastLine(), RPARENTLack); // errorCode : j    

            } else {  // PrimaryExp
                        child = ++ treeNum;
                        
                        Tree[child].father = (unaryExp);
                        Tree[unaryExp].children.push_back(child);

                        dfs_PrimaryExp(depth + 1);
                    }
            return unaryExp;
        }

        int dfs_UnaryOp(int depth) {
            /* UnaryOp → '+' | '−' | '!' */
            int unaryOp = treeNum;
            makeTree(unaryOp,GrammarItem::UnaryOp, depth + 1); 
            assert(lexerResult[pos].tk == tokenType::PLUS
                || lexerResult[pos].tk == tokenType::MINU
                || lexerResult[pos].tk == tokenType::NOT);
            int child = ++treeNum;
            makeLeaf(child,lexerResult[pos].tk,depth+1,unaryOp,lexerResult[pos].content,lexerResult[pos].line);
            return unaryOp;
        }

        int dfs_FuncRParams(int depth) {
            /* FuncRParams → Exp { ',' Exp } */
            int exp = treeNum;
            makeTree(exp,GrammarItem::FuncRParams, depth);
            int child;
            // Exp
            
            child = ++treeNum;
            Tree[child].father = (exp);
            Tree[exp].children.push_back(child);
            this->dfs_Exp(depth + 1);
            // { ',' Exp }
            while (lexerResult[pos].tk == tokenType::COMMA) {
                child = ++treeNum;
                
                makeLeaf(child,lexerResult[pos].tk,depth+1,exp,lexerResult[pos].content,lexerResult[pos].line);
                // Exp
                child = ++treeNum;
                Tree[child].father = (exp);
                Tree[exp].children.push_back(child);
                dfs_Exp(depth + 1);
            }
            return exp;
        }
        // 对于dfs_mulExp,dfs_addExp等过程，调用前不知道系欸但的最终坐标，所以不能先赋值再调用
        int dfs_MulExp(int depth) {
            /* 改写后： MulExp -> UnaryExp {('*' | '/' | '%') UnaryExp} */
            
            
            
            int current = ++treeNum;
            makeTree(current, GrammarItem::MulExp, depth);
            int child = ++treeNum;
            Tree[current].children.push_back(child);
            Tree[child].father = (current);
            dfs_UnaryExp(depth+1);
            while (lexerResult[pos].tk == tokenType::MULT
                || lexerResult[pos].tk == tokenType::DIV
                || lexerResult[pos].tk == tokenType::MOD) {
                // dfs
                
                int temp = ++treeNum;
                makeTree(temp, GrammarItem::MulExp, depth);
                
                Tree[temp].children.push_back(current);
                Tree[current].father = temp;
                
                current = temp;
                // ('*' | '/' | '%')
                
                
                child = ++treeNum;
                makeLeaf(child, lexerResult[pos].tk, depth+1,current,lexerResult[pos].content,lexerResult[pos].line);
                // UnaryExp
                child = ++treeNum;
                Tree[current].children.push_back(child);
                Tree[child].father = current;
                dfs_UnaryExp(depth + 1);
            }
            // TODO: 递归修改
            return current;
        }

        int dfs_AddExp(int depth) {
            /* 改写后: AddExp → MulExp {('+' | '−') MulExp} */
            
            int current = ++treeNum;
            makeTree(current, GrammarItem::AddExp, depth);
            int child;
            
                child = dfs_MulExp(depth+1);
                Tree[current].children.push_back(child);
                Tree[child].father = (current);
               
            while (lexerResult[pos].tk == tokenType::PLUS
                || lexerResult[pos].tk == tokenType::MINU) {
                // dfs
                
                int temp = ++treeNum;
                makeTree(temp, GrammarItem::AddExp, depth);
                
                Tree[temp].children.push_back(current);
                Tree[current].father = temp;
                
                current = temp;
                
                child = ++treeNum;
                makeLeaf(child, lexerResult[pos].tk, depth+1,current,lexerResult[pos].content,lexerResult[pos].line);
                // UnaryExp
                child = this->dfs_MulExp(depth + 1);
                Tree[current].children.push_back(child);

            }
            // TODO: 递归修改
            //cout<<lexerResult[pos].content<<endl;
            return current;
        }

        int dfs_RelExp(int depth) {
            /* 改写后： RelExp → AddExp {('<' | '>' | '<=' | '>=') AddExp} */
            
            int current = ++treeNum;
            makeTree(current, GrammarItem::RelExp, depth);
            int child = dfs_AddExp(depth+1);
            Tree[current].children.push_back(child);
            Tree[child].father = (current);
            while (lexerResult[pos].tk == tokenType::LEQ
                || lexerResult[pos].tk == tokenType::LSS
                || lexerResult[pos].tk == tokenType::GEQ
                || lexerResult[pos].tk == tokenType::GRE) {
                // dfs
                
                int temp = ++treeNum;
                makeTree(temp, GrammarItem::RelExp, depth);
                
                Tree[temp].children.push_back(current);
                Tree[current].father = temp;
                
                current = temp;
                // ('*' | '/' | '%')
                child = ++treeNum;
                makeLeaf(child, lexerResult[pos].tk, depth+1,current,lexerResult[pos].content,lexerResult[pos].line);
                // UnaryExp
                child = this->dfs_AddExp(depth + 1);
                Tree[current].children.push_back(child);
                Tree[child].father = current;
            }
            // TODO: 递归修改
            return current;
        }
        
        int dfs_EqExp(int depth) {
            /* 改写后： EqExp → RelExp {('==' | '!=') RelExp} */
            int current = ++treeNum;
            makeTree(current, GrammarItem::EqExp, depth);
            int child = dfs_RelExp(depth+1);
            
            Tree[current].children.push_back(child);
            Tree[child].father = (current);
            while (lexerResult[pos].tk == tokenType::EQL
                || lexerResult[pos].tk == tokenType::NEQ) {
                // dfs
                int temp = ++treeNum;
                makeTree(temp, GrammarItem::EqExp, depth);
                
                Tree[temp].children.push_back(current);
                Tree[current].father = temp;
                
                current = temp;
                // ('*' | '/' | '%')
                
                
                child = ++treeNum;
                makeLeaf(child, lexerResult[pos].tk, depth+1,current,lexerResult[pos].content,lexerResult[pos].line);
                // UnaryExp
                child = this->dfs_RelExp(depth + 1);
                Tree[current].children.push_back(child);
                Tree[child].father = (current);
            }
            // TODO: 递归修改
            return current;
        }
        
        int dfs_LAndExp(int depth) {
            /* 改写后: LAndExp → EqExp {'&&' EqExp} */
            int current = ++treeNum;
            makeTree(current, GrammarItem::LAndExp, depth);
            int child = dfs_EqExp(depth+1);
            Tree[current].children.push_back(child);
            Tree[child].father = (current);
            while (lexerResult[pos].tk == tokenType::AND) {
                // dfs
                
                int temp = ++treeNum;
                makeTree(temp, GrammarItem::LAndExp, depth);
                
                Tree[temp].children.push_back(current);
                Tree[current].father = temp;
                
                current = temp;
                // ('*' | '/' | '%')
                
                
                child = ++treeNum;
                makeLeaf(child, lexerResult[pos].tk, depth+1,current,lexerResult[pos].content,lexerResult[pos].line);
                // UnaryExp
                child = this->dfs_EqExp(depth + 1);
                Tree[current].children.push_back(child);
            }
            // TODO: 递归修改
            return current;
        }     
        
        int dfs_LOrExp(int depth) {
            /* 改写后： LOrExp → LAndExp {'||' LAndExp} */
            int current = ++treeNum;
            makeTree(current, GrammarItem::LOrExp, depth);
            int child = dfs_LAndExp(depth+1);
            Tree[current].children.push_back(child);
            Tree[child].father = (current);
            while (lexerResult[pos].tk == tokenType::OR) {
                // dfs
                
                int temp = ++treeNum;
                makeTree(temp, GrammarItem::LOrExp, depth);
                
                Tree[temp].children.push_back(current);
                Tree[current].father = temp;
                
                current = temp;
                // ('*' | '/' | '%')
                
                
                child = ++treeNum;
                makeLeaf(child, lexerResult[pos].tk, depth+1,current,lexerResult[pos].content,lexerResult[pos].line);
                // UnaryExp
                child = this->dfs_LAndExp(depth + 1);
                Tree[current].children.push_back(child);
            }
            // TODO: 递归修改
            return current;
        }

        void Output(int root){
            dfs(root);
        }
        
        void dfs(int x){
            
            if(Tree[x].children.size()==0){
                Tree[x].isLeaf = true;
                cout<<tokenType2string(Tree[x].tk)<<' '<<Tree[x].tkContent<<endl;
                return;
            }
            for(auto son:Tree[x].children){
                dfs(son);
            }
            
            if(need2print(Tree[x].gi)){
                cout<<grammarItem2string[Tree[x].gi]<<endl;
            }
        }  
        int need2print(GrammarItem item){
            if(item == GrammarItem::BlockItem) return 0;
            if(item == GrammarItem::Decl) return 0;
            if(item == GrammarItem::BType) return 0;
            return 1;
        }
    protected:
        int treeNum,pos;
};
static int ifIndex,forIndex,funcIndex,callIndex=1;
class midCodeLine{
    
    
    public:
        opType op;
        string arg1;
        string arg2;
        string arg3;
        void setIndex(int id){
            this->arg3 = ""+to_string(id);
        }
        midCodeLine(){
            this->op = opType::print_int;
            arg1 = arg2 =arg3 = "";
        }
        midCodeLine(opType op,string arg1,string arg2,string arg3) {
            this->op = op;
            if(op == opType::if_begin)ifIndex++;
            if(op == opType::for_begin)forIndex++;
            if(op == opType::func_begin)funcIndex++;
            this->arg1 = arg1;
            this->arg2 = arg2;
            this->arg3 = arg3;
            if(op == opType::if_begin)this->arg3 = to_string(ifIndex) + "";
            if(op == opType::for_begin)this->arg3 = to_string(forIndex) + "";
            if(op == opType::func_begin)this->arg3 = to_string(funcIndex) + "";
            if(op == opType::call) {
                this->arg3 = to_string(callIndex) + "";
                callIndex++;
            }
        
        }
        static string stringOf(string arg){
            if(arg == "") return "";
            return arg;
        }
        static int getIfIndex() {
            return ifIndex;
        }
        static int getForIndex() {
            return forIndex;
        }
        static int getFuncIndex() {
            return funcIndex;
        }
        static int getCallIndex() {
            return callIndex;
        }
        int my_max(int a, int b){
            return a > b ? a : b;
        }
        string getInfo(){
            //return opType2string[op] + ",   "+arg1+",    "+arg2+",    "+arg3; 
            string temp = opType2string[op];
            string str1 = temp.append(my_max(0,12-temp.length()),' ');
            string str2 = arg1.append(my_max(0,12-arg1.length()),' ');
            string str3 = arg2.append(my_max(0,12-arg2.length()),' ');
            string str4 = arg3.append(my_max(0,12-arg3.length()),' ');
            string strgap = ",     ";
            return str1 + strgap + str2 + strgap + str3 + strgap + str4;
        }
};
bool freeRegFlag[10];


class Intermediator{
    public:
        
        int id;
        int regNum_t = 10;
        int regmax = -1;
        int intSize = 4;
        
        bool globalFlag = true;
        string  currentIdentifier;
        bool ptrLVal = false; //current LVal is int[]{[]}
        vector<int> dimSize;
        int currentForIndex = -1;
        vector<midCodeLine> midCode;
        int constAddress = 0;
        map<int,int> constValue;
        map<string,int> varInfoMap ;
        //int a[2][3]; 	'a@' = 2, 'a@0' = 24, 'a@1' = 12, 'a@2' = 4
	    //int b;		'b@' = 0, 'b@0' = 4
        void printInfo(){
            //freopen("midcode.txt","w",stdout);
            //for(auto code:midCode) cout<<code.getInfo()<<endl;
        }
        void initDims() {
            dimSize.clear();
        }
        void printMax(){
            cout<<"regmax:"<<' '<<regmax<<endl;
        }
        void pushCode(opType op,string arg1,string arg2,string arg3){
            //cout<<opType2string[op]<<" "<<arg1<<" "<<arg2<<" "<<arg3<<endl;
            midCode.push_back(midCodeLine(op,arg1,arg2,arg3));
        }
        void newConst(string name,int size){
            assert(varInfoMap.find(name)==varInfoMap.end());
            putVarInfo(name,constAddress);
            constAddress+=size;
        }
        vector<string> stringSplit(const std::string& str, char delim) {
            std::stringstream ss(str);
            std::string item;
            std::vector<std::string> elems;
            while (std::getline(ss, item, delim)) {
                if (!item.empty()) {
                    elems.push_back(item);
                }
            }
            return elems;
        }
        int getVarInfo(string name){
            assert(varInfoMap.count(name));
            int val = varInfoMap[name];
            return val;
        }
        void putVarInfo(string name,int value){
            varInfoMap[name]=value;
        }
        void putConstValue(int offset,int value){
            constValue[constAddress+offset] = value;
        }
        int getConstValue(string name,int offset){
            int size = varInfoMap[name+"@"+"0"];
            assert(offset<size && offset>=0);
            int address = varInfoMap[name];
            return constValue[address+offset];
        }
        void recordDims(int size){
            int index;
            int dims = dimSize.size();
            //cout<<currentIdentifier<<' '<<size<<' '<<dims<<endl;
            putVarInfo(currentIdentifier+"@",dims);
            for(int i=0;i<dims;i++){
                putVarInfo(currentIdentifier+"@"+to_string(i),size);
                size /= dimSize[i];
            }
            putVarInfo(currentIdentifier+"@"+to_string(dims),size);
            assert(size == 4);
        }
        bool allFree(){
            for(int i=0;i<regNum_t;i++){
                if(freeRegFlag[i]){
                    cout<<"reg "+to_string(i)+" is NOT free"<<endl;
                    return 0;
                }
                
            }
            return 1;
        }
        int getFreeReg(string info){
            for(int i=0;i<regNum_t;i++){
                if(!freeRegFlag[i]){
                    freeRegFlag[i] = 1;
                    if(regmax<i) regmax = i;
                    return i;
                }

            }
            cout<<"no free regs"<<endl;
            assert(1<0);
            return -1;
        }
        void freeReg(int index){
            assert(freeRegFlag[index]);
            freeRegFlag[index] = 0;
        }
        void saveRegs(){
            for(int index = 0,sindex = 0;index<regNum_t;index++){
                if(freeRegFlag[index]){
                    pushCode(opType::save,to_string(sindex),"",to_string(index));
                    sindex++;
                }
            }
        }
        void loadRegs(){
            for(int index = 0,sindex = 0;index<regNum_t;index++){
                if(freeRegFlag[index]){
                    pushCode(opType::load,to_string(sindex),"",to_string(index));
                    sindex++;
                }
            }
        }
        void process(){
            //cout<<111<<endl;
            midCode_compUnit(1);
        }
        void midCode_compUnit(int comp){
            globalFlag = true;
            int k = 0;
            for(auto son:Tree[comp].children){
                //cout<<(++k)<<endl;
                if(Tree[son].gi == GrammarItem::Decl) midCode_decl(son);
            }
            globalFlag = false;
            for(auto son:Tree[comp].children){
                if(Tree[son].gi == GrammarItem::FuncDef) midCode_funcDef(son);
            }
            for(auto son:Tree[comp].children){
                if(Tree[son].gi == GrammarItem::MainFuncDef) midCode_mainFuncDef(son);
            }
        }
        void midCode_decl(int decl){
            int son = Tree[decl].children[0];
            if(Tree[son].gi == GrammarItem::VarDecl){
                midCode_varDecl(son);
                return;
            }
            if(Tree[son].gi == GrammarItem::ConstDecl){
                midCode_constDecl(son);
                return;
            }
        }
        void midCode_constDecl(int cd){
            int son = Tree[cd].children[0];
            //const Btype constdef
            son = Tree[cd].children[2];
            assert(Tree[son].gi == GrammarItem::ConstDef);
            midCode_constDef(son);
            // const int aza = 200,aza2 = 300 ;
            //cout<<Tree[cd].children.size()<<endl;
            for(int i=2;i<Tree[cd].children.size()-1;){
                i++;
                son = Tree[cd].children[i];
                if(Tree[son].tk == tokenType::SEMICN) break;
                assert(Tree[son].tk == tokenType::COMMA);
                
                i++;
                son = Tree[cd].children[i];
                assert(Tree[son].gi == GrammarItem::ConstDef);
                midCode_constDef(son);
            }
        }
        void midCode_constDef(int cd){
            int son = Tree[cd].children[0];
            assert(Tree[son].tk == tokenType::IDENFR);
            currentIdentifier = Tree[son].tkContent;
            //cout<<currentIdentifier<<" "<<Tree[son].blockid<<endl;
            initDims();
            int dim = 0,size = intSize;
            for(int i=1;i<Tree[cd].children.size()-1;){
                son = Tree[cd].children[i];
                if(Tree[son].tk == tokenType::ASSIGN) break;
                assert(Tree[son].tk == tokenType::LBRACK);
                if(Tree[son].tk == tokenType::LBRACK) dim++;
                i++;
                son =Tree[cd].children[i];
                assert(Tree[son].gi == GrammarItem::ConstExp);
                int res = midCode_constExp(son);
                dimSize.push_back(res);
                size*=res;
                i++;
                son = Tree[cd].children[i];
                assert(Tree[son].tk == tokenType::RBRACK);
                i++;
            }
            recordDims(size);
            // 生成代码1
            pushCode(opType::alloc,currentIdentifier,to_string(size),to_string(dim));

            for(auto p :Tree[cd].children) if(Tree[p].gi == GrammarItem::ConstInitVal) {
                midCode_constInitVal(p,dim,dim,0);
            }
            newConst(currentIdentifier,size);
            
        }
        // a[2][3] = {{1,2,3},{3,4,5}}
        void midCode_constInitVal(int ci,int nowdim,int totaldim,int offset){
            int son = Tree[ci].children[0];
            if(nowdim == 0){
                assert(Tree[son].gi == GrammarItem::ConstExp);
                int res = midCode_constExp(son);
                pushCode(opType::sw,currentIdentifier,to_string(offset),to_string(res));
                putConstValue(offset,res);
                return;
            }
            int size = getVarInfo(currentIdentifier+"@"+to_string((totaldim-nowdim+1)));
            son = Tree[ci].children[0];
            assert(Tree[son].tk == tokenType::LBRACE);
            son = Tree[ci].children[1];
            if(Tree[son].tk == tokenType::RBRACE) return;
            assert(Tree[son].gi == GrammarItem::ConstInitVal);
            midCode_constInitVal(son,nowdim-1,totaldim,offset);
            for(int i=2;i<Tree[ci].children.size()-1;i++){
                son = Tree[ci].children[i];
                if(Tree[son].tk == tokenType::RBRACE) return;
                assert(Tree[son].tk == tokenType::COMMA);
                i++;
                son = Tree[ci].children[i];
                assert(Tree[son].gi == GrammarItem::ConstInitVal);
                offset += size;
                midCode_constInitVal(son,nowdim-1,totaldim,offset);
            }
        }
        void midCode_varDecl(int vd){
            int son = Tree[vd].children[0];
            assert(Tree[son].gi == GrammarItem::BType);

            for(auto son : Tree[vd].children)
            if(Tree[son].gi == GrammarItem::VarDef){
                midCode_varDef(son);
            }
        }
        void midCode_varDef(int vd){
            int size = intSize,nowDim = 0;
            for(auto i:Tree[vd].children){
                if(Tree[i].tk == tokenType::IDENFR){
                    currentIdentifier = Tree[i].tkContent;
                    //cout<<currentIdentifier<<" "<<Tree[i].blockid<<endl;
                    break;
                }
            }

            initDims();
            int i = 0;
            while(i<Tree[vd].children.size()-1){
                i++;
                int son = Tree[vd].children[i];
                if(Tree[son].tk == tokenType::ASSIGN) break;
                //cout<<Tree[son].tkContent<<' '<<Tree[son].line<<endl;
                assert(Tree[son].tk == tokenType::LBRACK);
                i++;
                son = Tree[vd].children[i];
                assert(Tree[son].gi == GrammarItem::ConstExp);
                int res = midCode_constExp(son);
                dimSize.push_back(res);
                size*=res;
                i++;
                son = Tree[vd].children[i];
                nowDim++;
                assert(Tree[son].tk == tokenType::RBRACK);
            }
            recordDims(size);
            pushCode(opType::alloc,currentIdentifier,to_string(size),to_string(nowDim));

            if(i>=Tree[vd].children.size()-1) return;
            assert(Tree[Tree[vd].children[++i]].gi == GrammarItem::InitVal);
            midCode_initVal(Tree[vd].children[i],nowDim,nowDim,0);
            //cout<<"vardef finished"<<endl;
        }
        void midCode_initVal(int iv,int nowDim,int totalDim,int offset){
            int i=0;
            if(nowDim == 0){
                assert(Tree[Tree[iv].children[i]].gi == GrammarItem::Exp);
                if(!globalFlag){
                    int reg = midCode_exp(Tree[iv].children[i]);
                    pushCode(opType::sw,currentIdentifier,to_string(offset),"$t"+to_string(reg));
                    freeReg(reg);
                }else{
                    int reg = midCode_constExp(Tree[iv].children[i]);
                    pushCode(opType::sw,currentIdentifier,to_string(offset),to_string(reg));

                }
                return;
            }
            int size = getVarInfo(currentIdentifier + "@" + to_string(totalDim - nowDim + 1));
            assert(Tree[Tree[iv].children[i]].tk == tokenType::LBRACE);
            i++;
            if(Tree[Tree[iv].children[i]].tk == tokenType::RBRACE) return;
            assert(Tree[Tree[iv].children[i]].gi == GrammarItem::InitVal);
            midCode_initVal(Tree[iv].children[i],nowDim-1,totalDim,offset);
            for(;i<Tree[iv].children.size()-1;){
                i++;
                if(Tree[Tree[iv].children[i]].tk == tokenType::RBRACE) return;
                assert(Tree[Tree[iv].children[i]].tk == tokenType::COMMA);
                i++;
                assert(Tree[Tree[iv].children[i]].gi == GrammarItem::InitVal);
                offset += size;
                midCode_initVal(Tree[iv].children[i],nowDim-1,totalDim,offset);
            }
        }
        void midCode_funcDef(int fd){
            string funcname;
            int i = 0,now = Tree[fd].children[i];

            for(;i<Tree[fd].children.size();i++){
                if(Tree[Tree[fd].children[i]].tk == tokenType::IDENFR) {
                    funcname = Tree[Tree[fd].children[i]].tkContent;
                    //cout<<funcname<<" "<<Tree[Tree[fd].children[i]].blockid<<endl;
                    break;
                }
            }
            pushCode(opType::func_begin,funcname,"","");
            int funcIndex = midCodeLine::getFuncIndex();

            i++;
            assert(Tree[Tree[fd].children[i]].tk == tokenType::LPARENT);
            i++;
            int argNum = 0;
            if(Tree[Tree[fd].children[i]].gi == GrammarItem::FuncFParams){
                argNum = midCode_funcFParams(Tree[fd].children[i]);
                i++;
                
            }
            putVarInfo(funcname,argNum);
            assert(Tree[Tree[fd].children[i]].tk == tokenType::RPARENT);
            i++;
            
            assert(Tree[Tree[fd].children[i]].gi == GrammarItem::Block);
            midCode_block(Tree[fd].children[i]);
            pushCode(opType::func_end,funcname,"",to_string(funcIndex));
            assert(allFree());
        }
        void midCode_mainFuncDef(int mfd){

            pushCode(opType::func_begin,"main","","");
            int funcIndex = midCodeLine::getFuncIndex();
            putVarInfo("main",0);
            for(auto i:Tree[mfd].children){
                if(Tree[i].gi == GrammarItem::Block){
                    midCode_block(i);
                    break;
                }
            }
            pushCode(opType::func_end,"main","",to_string(funcIndex));
            assert(allFree());
        }
        int midCode_funcFParams(int fp){
            int argIndex  = 0;
            for(auto i:Tree[fp].children){
                if(Tree[i].gi == GrammarItem::FuncFParam){
                   midCode_funcFParam(i,argIndex++);
                }
            }
            return argIndex;
        }
        void midCode_funcFParam(int fp,int argIndex){
            for(auto i:Tree[fp].children){
                if(Tree[i].tk == tokenType::IDENFR){
                    currentIdentifier = Tree[i].tkContent;
                    //cout<<currentIdentifier<<" "<<Tree[i].blockid<<endl;
                    break;
                }
            }
            int size = intSize,nowDim = 0;
            initDims();
            int i = 1;
            for(;i<Tree[fp].children.size()-1;){
                i++;
                assert(Tree[Tree[fp].children[i]].tk == tokenType::LBRACK);
                i++;
                if(nowDim != 0){
                    assert(Tree[Tree[fp].children[i]].gi == GrammarItem::ConstExp);
                    int res = midCode_constExp(Tree[fp].children[i]);
                    size*=res;
                    dimSize.push_back(res);
                    i++;
                }else dimSize.push_back(1);
                assert(Tree[Tree[fp].children[i]].tk == tokenType::RBRACK);
                nowDim++;

            }
            recordDims(size);
            pushCode(opType::fparam,currentIdentifier,"",to_string(argIndex));
        }
        void midCode_block(int bl){
            
            for(auto p:Tree[bl].children){
                if(Tree[p].gi == GrammarItem::BlockItem) midCode_blockItem(p);
            }
        }
        void midCode_blockItem(int bi){
            
            int son = Tree[bi].children[0];
            
            //cout<<grammarItem2string[Tree[son].gi]<<endl;
            if(Tree[son].gi == GrammarItem::Decl) {
                midCode_decl(son);
                return;
            }
            if(Tree[son].gi == GrammarItem::Stmt) {
                midCode_stmt(son);
                return;
            }
            assert(1<0);
        }
        void midCode_stmt(int st){
            //cout<<"stmt"<<endl;
            int now = Tree[st].children[0];
            if(Tree[now].gi == GrammarItem::LVal){
                int regIndex1 = getFreeReg("Stmt -  LVal");
                currentIdentifier = midCode_lval(now,"$t"+to_string(regIndex1));
                now = Tree[st].children[1];
                assert(Tree[now].tk == tokenType::ASSIGN);
                now = Tree[st].children[2];
                if(Tree[now].tk == tokenType::GETINTTK){
                    pushCode(opType::get_int,"","","");
                    pushCode(opType::sw,currentIdentifier,"$t"+to_string(regIndex1),"$v0");
                    freeReg(regIndex1);
                    return;
                }
                if(Tree[now].gi == GrammarItem::Exp){
                    int regIndex2 = midCode_exp(now);
                    pushCode(opType::sw,currentIdentifier,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2));
                    freeReg(regIndex1);
                    freeReg(regIndex2);
                    return;
                }
                assert(1<0);
            }
            if(Tree[now].gi == GrammarItem::Block){
                midCode_block(now);
                return;
            }
            if(Tree[now].tk == tokenType::IFTK){
                int i= 1;
                assert(Tree[Tree[st].children[i]].tk == tokenType::LPARENT);
                i++;
                assert(Tree[Tree[st].children[i]].gi == GrammarItem::Cond);
                int regIndex = midCode_cond(Tree[st].children[i]);
                pushCode(opType::if_begin,"$t"+to_string(regIndex),"","");
                freeReg(regIndex);
                int ifIndex = midCodeLine::getIfIndex();
                i++;
                assert(Tree[Tree[st].children[i]].tk == tokenType::RPARENT);
                i++;
                assert(Tree[Tree[st].children[i]].gi == GrammarItem::Stmt);
                midCode_stmt(Tree[st].children[i]);
                pushCode(opType::else_begin,"","",to_string(ifIndex));
                if(i<Tree[st].children.size()-1){
                    i++;
                    assert(Tree[Tree[st].children[i]].tk == tokenType::ELSETK);
                    i++;
                    assert(Tree[Tree[st].children[i]].gi == GrammarItem::Stmt);
                    midCode_stmt(Tree[st].children[i]);
                }
                pushCode(opType::if_end,"","",to_string(ifIndex));
                return;
            }
            if(Tree[now].tk == tokenType::FORTK){
                int i = 1;

                assert(Tree[Tree[st].children[i]].tk == tokenType::LPARENT);
                i++;
                if(Tree[Tree[st].children[i]].gi == GrammarItem::ForStmt){

                    midCode_forStmt(Tree[st].children[i]);
                    i++;

                }
                assert(Tree[Tree[st].children[i]].tk == tokenType::SEMICN);
                pushCode(opType::for_begin,"","","");
                int forIndex = currentForIndex;
                currentForIndex = midCodeLine::getForIndex();
                i++;
                string regName = "";
                if(Tree[Tree[st].children[i]].gi== GrammarItem::Cond){
                    int regIndex = midCode_cond(Tree[st].children[i]);
                    regName = "$t"+to_string(regIndex);
                    freeReg(regIndex);
                    i++;
                }
                
                assert(Tree[Tree[st].children[i]].tk == tokenType::SEMICN);
                pushCode(opType::for_cond,regName,"",to_string(currentForIndex));
                i++;
                int loop = 0;
                if(Tree[Tree[st].children[i]].gi == GrammarItem::ForStmt){
                    loop = Tree[st].children[i];
                    i++;
                }
                assert(Tree[Tree[st].children[i]].tk == tokenType::RPARENT);
                i++;
                assert(Tree[Tree[st].children[i]].gi == GrammarItem::Stmt);
                midCode_stmt(Tree[st].children[i]);
                pushCode(opType::for_auto,"","",to_string(currentForIndex));
                if(loop!=0) midCode_forStmt(loop);
                pushCode(opType::for_end,"","",to_string(currentForIndex));
                currentForIndex = forIndex;
                return ;
            }
            if(Tree[now].tk == tokenType::BREAKTK){
                pushCode(opType::for_break,"","",to_string(currentForIndex));
                return;
            }
            if(Tree[now].tk == tokenType::CONTINUETK){
                pushCode(opType::for_continue,"","",to_string(currentForIndex));
                return;
            }
            if(Tree[now].tk == tokenType::RETURNTK){
                int funcIndex = midCodeLine::getFuncIndex();
                string regName = "";
                now = Tree[st].children[1];
                if(Tree[now].gi == GrammarItem::Exp){
                    int regIndex = midCode_exp(now);
                    regName = "$t"+to_string(regIndex);
                    freeReg(regIndex);

                }
                pushCode(opType::func_return,regName,"",to_string(funcIndex));
                return;
            }
            if(Tree[now].tk == tokenType::PRINTFTK){
                now = Tree[st].children[1];
                assert(Tree[now].tk == tokenType::LPARENT);
                now = Tree[st].children[2];
                assert(Tree[now].tk == tokenType::STRCON);
                string str = Tree[now].tkContent;

                str = str.substr(1,str.length()-2);
                //str.replace("%d","#%d#");
                string strtemp = str;
                str = "";
                for(int i=0;i<strtemp.length();i++){
                    if((i<strtemp.length()-1)&&(strtemp[i]=='%')&&(strtemp[i+1]=='d')){
                        str = str+"#%d#";
                        i++;
                    }else str+=strtemp[i];
                }


                int i = 2;
                vector<string> constString = stringSplit(str,'#');
                for(int stri=0;stri<constString.size();stri++){
                    if(constString[stri]=="%d"){
                        i++;
                        now = Tree[st].children[i];
                        if(Tree[now].tk == tokenType::RPARENT) break;
                        assert(Tree[now].tk == tokenType::COMMA);
                        now = Tree[st].children[++i];
                        assert(Tree[now].gi == GrammarItem::Exp);
                        int regIndex = midCode_exp(now);
                        pushCode(opType::print_int,"$t"+to_string(regIndex),"","");
                        freeReg(regIndex);
                        continue;
                    }
                    if(constString[stri]==""){
                        continue;
                    }
                    pushCode(opType::print_string,constString[stri],"","");
                }
                return;
            }
            if(Tree[now].gi == GrammarItem::Exp){
                freeReg(midCode_exp(now));
            }
        }
        void midCode_forStmt(int fst){
            int i = 0;
            int now = Tree[fst].children[i];
            int regIndex1 = getFreeReg("Forstmt");
            currentIdentifier = midCode_lval(now,"$t"+to_string(regIndex1));
            now = Tree[fst].children[++i];
            assert(Tree[now].tk == tokenType::ASSIGN);
            now = Tree[fst].children[++i];
            assert(Tree[now].gi == GrammarItem::Exp);
            int regIndex2 = midCode_exp(now);
            pushCode(opType::sw,currentIdentifier,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2));
            freeReg(regIndex1);
            freeReg(regIndex2);
        }
        int midCode_exp(int exp){
            int now = Tree[exp].children[0];
            assert(Tree[now].gi == GrammarItem::AddExp);
            return midCode_addExp(now);
        }
        int midCode_cond(int cond){
            int now = Tree[cond].children[0];
            assert(Tree[now].gi == GrammarItem::LOrExp);
            return midCode_lorExp(now);
        }
        string midCode_lval(int lv,string off_pos){
            int i = 0;
            int now = Tree[lv].children[0];
            assert(Tree[now].tk == tokenType::IDENFR);
            //cout<<Tree[now].tkContent<<" "<<Tree[now].blockid<<endl;
            string identifier = Tree[now].tkContent;
            pushCode(opType::mov,"$0","",off_pos);
            int dim;
            for(dim = 1;i<Tree[lv].children.size()-1;dim++){
                now = Tree[lv].children[++i];
                assert(Tree[now].tk == tokenType::LBRACK);
                now = Tree[lv].children[++i];
                assert(Tree[now].gi == GrammarItem::Exp);
                int regIndex = midCode_exp(now);
                int size = getVarInfo(identifier+"@"+to_string(dim));
                string regName ="$t"+ to_string(regIndex);
                pushCode(opType::mult,regName,to_string(size),regName);
                pushCode(opType::plus,off_pos,regName,off_pos);
                freeReg(regIndex);
                now = Tree[lv].children[++i];
                assert(Tree[now].tk == tokenType::RBRACK);
            }
            ptrLVal = (dim<= getVarInfo(identifier + "@"));
            return identifier;
        }
        int midCode_primaryExp(int pe){
            int i = 0;
            int now = Tree[pe].children[0];
            if(Tree[now].gi == GrammarItem::LVal){
                int regIndex1 = getFreeReg("PrimaryExp-Lval");
                string identifier = midCode_lval(now,"$t" + to_string(regIndex1));
                int regIndex2 = getFreeReg("PrimaryExp-Res");
                if(ptrLVal){
                    pushCode(opType::address,identifier,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2));
                }else pushCode(opType::lw,identifier,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2));
                freeReg(regIndex1);
                ptrLVal = false;
                return regIndex2;
            }
            if(Tree[now].gi == GrammarItem::Number){
                int regIndex1 = getFreeReg("PrimaryExp-Res");
                midCode_number(now,"$t"+to_string(regIndex1));
                return regIndex1;
            }
            assert(Tree[now].tk == tokenType::LPARENT);
            now = Tree[pe].children[1];
            assert(Tree[now].gi == GrammarItem::Exp);
            return midCode_exp(now);
        }
        void midCode_number(int num,string regName){
    
            int now = Tree[num].children[0];
            assert(Tree[now].tk == tokenType::INTCON);
            int con = atoi(Tree[now].tkContent.c_str());
            pushCode(opType::li,to_string(con),"",regName);
        }
        int midCode_unaryExp(int ue){
            //cout<<"ue"<<endl;
            int i = 0;
            int now = Tree[ue].children[i];
            if(Tree[now].gi == GrammarItem::PrimaryExp){
                return midCode_primaryExp(now);
            }
            if(Tree[now].gi == GrammarItem::UnaryOp){
                
                opType op = midCode_unaryOp(now);
                now = Tree[ue].children[++i];
                assert(Tree[now].gi == GrammarItem::UnaryExp);
                int regIndex = midCode_unaryExp(now);
                pushCode(op,"$t"+to_string(regIndex),"","$t"+to_string(regIndex));
                return regIndex;
            }
            assert(Tree[now].tk == tokenType::IDENFR);
            string identifier = Tree[now].tkContent;
            //cout<<identifier<<" "<<Tree[now].blockid<<endl;
            now = Tree[ue].children[++i];
            assert(Tree[now].tk == tokenType::LPARENT);
            now = Tree[ue].children[++i];
            int callIndex = midCodeLine::getCallIndex();
            if(Tree[now].gi == GrammarItem::FuncRParams){
                midCode_funcRParams(now,callIndex);
            }
            saveRegs();
            pushCode(opType::call,identifier,"","");
            loadRegs();
            int regIndex = getFreeReg("UnaryExp - FunRes");
            pushCode(opType::mov,"$v0","","$t"+to_string(regIndex));
            return regIndex;
        }
        opType midCode_unaryOp(int op){
            int now = Tree[op].children[0];
            if(Tree[now].tk == tokenType::PLUS) return opType::mov;
            if(Tree[now].tk == tokenType::MINU) return opType::neg;
            if(Tree[now].tk == tokenType::NOT) return opType::NOT;
            assert(1<0);
            return opType::mov;
        }
        void midCode_funcRParams(int frp,int callIndex){
            int i = 0;
            int now = Tree[frp].children[0];
            assert(Tree[now].gi == GrammarItem::Exp);
            int regIndex = midCode_exp(now);
            pushCode(opType::rparam,"$t"+to_string(regIndex),to_string(callIndex),"0");
            freeReg(regIndex);
            for(int argIndex = 0; i<Tree[frp].children.size()-1;argIndex++){
                now = Tree[frp].children[++i];
                assert(Tree[now].tk == tokenType::COMMA);
                now = Tree[frp].children[++i];
                assert(Tree[now].gi == GrammarItem::Exp);
                regIndex = midCode_exp(now);
                pushCode(opType::rparam,"$t"+to_string(regIndex),to_string(callIndex),to_string(argIndex));
                freeReg(regIndex);
            }
        }
        opType midCode_BiOp(int lx){
            if(Tree[lx].tk == tokenType::MULT) return opType::mult;
            if(Tree[lx].tk == tokenType::DIV) return opType::DIV;
            if(Tree[lx].tk == tokenType::MOD) return opType::mod;
            if(Tree[lx].tk == tokenType::PLUS) return opType::plus;
            if(Tree[lx].tk == tokenType::MINU) return opType::minu;
            if(Tree[lx].tk == tokenType::GRE) return opType::gre;
            if(Tree[lx].tk == tokenType::LSS) return opType::lss;
            if(Tree[lx].tk == tokenType::GEQ) return opType::geq;
            if(Tree[lx].tk == tokenType::LEQ) return opType::leq;
            if(Tree[lx].tk == tokenType::EQL) return opType::eql;
            if(Tree[lx].tk == tokenType::NEQ) return opType::neq;
            assert(1<0);
            return opType::mult;
        }
        int midCode_mulExp(int me){
            int i = 0,now = Tree[me].children[0];
            if(Tree[now].gi == GrammarItem::UnaryExp) return midCode_unaryExp(now);
            assert(Tree[now].gi == GrammarItem::MulExp);
            int regIndex1 = midCode_mulExp(now);
            now = Tree[me].children[++i];
            opType op =  midCode_BiOp(now);
            now = Tree[me].children[++i];
            assert(Tree[now].gi == GrammarItem::UnaryExp);
            int regIndex2 = midCode_unaryExp(now);
            pushCode(op,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2),"$t"+to_string(regIndex1));
            freeReg(regIndex2);
            return regIndex1;
        }
        int midCode_addExp(int ap){
            int i= 0,now = Tree[ap].children[0];
            if(Tree[now].gi == GrammarItem::MulExp) return midCode_mulExp(now);
            assert(Tree[now].gi == GrammarItem::AddExp);
            int regIndex1 = midCode_addExp(now);
            now = Tree[ap].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[ap].children[++i];
            assert(Tree[now].gi == GrammarItem::MulExp);
            int regIndex2 = midCode_mulExp(now);
            pushCode(op,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2),"$t"+to_string(regIndex1));
            freeReg(regIndex2);
            return regIndex1;
        }
        int midCode_relExp(int re){
            //cout<<"relExp:"<<endl;
            int i = 0,now = Tree[re].children[0];
            if(Tree[now].gi == GrammarItem::AddExp) return midCode_addExp(now);
            assert(Tree[now].gi == GrammarItem::RelExp);
            int regIndex1 = midCode_relExp(now);
            now = Tree[re].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[re].children[++i];
            assert(Tree[now].gi == GrammarItem::AddExp);
            int regIndex2 = midCode_addExp(now);
            pushCode(op,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2),"$t"+to_string(regIndex1));
            freeReg(regIndex2);
            return regIndex1;
        }
        int midCode_eqExp(int re){
            int i = 0,now = Tree[re].children[0];
            if(Tree[now].gi == GrammarItem::RelExp) return midCode_relExp(now);
            assert(Tree[now].gi == GrammarItem::EqExp);
            int regIndex1 = midCode_eqExp(now);
            now = Tree[re].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[re].children[++i];
            assert(Tree[now].gi == GrammarItem::RelExp);
            int regIndex2 = midCode_relExp(now);
            pushCode(op,"$t"+to_string(regIndex1),"$t"+to_string(regIndex2),"$t"+to_string(regIndex1));
            freeReg(regIndex2);
            return regIndex1;
        }
        int midCode_lAndExp(int lae){
            //<<"midCode_andExp"<<endl;
            int i = 0,now = Tree[lae].children[0];
            if(Tree[now].gi == GrammarItem::EqExp){
                return midCode_eqExp(now);
            }
            assert(Tree[now].gi == GrammarItem::LAndExp);
            int regIndex1 = midCode_lAndExp(now);
            pushCode(opType::if_begin,"$t"+to_string(regIndex1),"and","");
            int ifIndex = midCodeLine::getIfIndex();
            now = Tree[lae].children[++i];
            assert(Tree[now].tk == tokenType::AND);
            now = Tree[lae].children[++i];
            assert(Tree[now].gi == GrammarItem::EqExp);
            int regIndex2 = midCode_eqExp(now);
            pushCode(opType::mov,"$t"+to_string(regIndex2),"","$t"+to_string(regIndex1));
            freeReg(regIndex2);
            pushCode(opType::else_begin,"","and",to_string(ifIndex));
            pushCode(opType::if_end,"","and",to_string(ifIndex));
            return regIndex1;
        }
        int midCode_lorExp(int le){
            //cout<<"midCode_lorExp"<<endl;
            int i = 0,now = Tree[le].children[0];
            if(Tree[now].gi == GrammarItem::LAndExp)  return midCode_lAndExp(now);
            assert(Tree[now].gi == GrammarItem::LOrExp);
            int regIndex1= midCode_lorExp(now);
            pushCode(opType::NOT,"$t"+to_string(regIndex1),"","$t"+to_string(regIndex1));
            pushCode(opType::if_begin,"$t"+to_string(regIndex1),"or","");
            int ifIndex = midCodeLine::getIfIndex();
            now = Tree[le].children[++i];
            assert(Tree[now].tk == tokenType::OR);
            now = Tree[le].children[++i];
            assert(Tree[now].gi == GrammarItem::LAndExp);
            int regIndex2 = midCode_lAndExp(now);
            pushCode(opType::NOT,"$t"+to_string(regIndex2),"","$t"+to_string(regIndex2));
            pushCode(opType::mov,"$t"+to_string(regIndex2),"","$t"+to_string(regIndex1));
            freeReg(regIndex2);
            pushCode(opType::else_begin,"","or",to_string(ifIndex));
            pushCode(opType::if_end,"","or",to_string(ifIndex));
            pushCode(opType::NOT,"$t"+to_string(regIndex1),"","$t"+to_string(regIndex1));
		    return regIndex1;

        }
        int midCode_constExp(int ce){
            int i = 0,now = Tree[ce].children[0];
            assert(Tree[now].gi == GrammarItem::AddExp);
            int res = midCode_constAddExp(now);
            return res;
        }
        int midCode_constLval(int clv){
            int i = 0,now = Tree[clv].children[0];
            string name = Tree[now].tkContent;
            int offset = 0;
            for(int dim = 1;i<Tree[clv].children.size()-1;dim++){
                now = Tree[clv].children[++i];
                assert(Tree[now].tk == tokenType::LBRACK);
                now = Tree[clv].children[++i];
                assert(Tree[now].gi == GrammarItem::Exp);
                int index = midCode_constExp(now);
                int size = getVarInfo(name + "@"+to_string(dim));
                offset += index*size;
                now = Tree[clv].children[++i];
                assert(Tree[now].tk == tokenType::RBRACK);

            }
            return getConstValue(name,offset);
        }
        int midCode_constPrimaryExp(int cpe){
            int i=0, now = Tree[cpe].children[0];
            if(Tree[now].gi == GrammarItem::LVal) return midCode_constLval(now);
            if(Tree[now].gi == GrammarItem::Number) return midCode_constNumber(now);
            assert(Tree[now].tk == tokenType::LPARENT);
            now = Tree[cpe].children[++i];
            assert(Tree[now].gi == GrammarItem::Exp);
            return midCode_constExp(now);     
        }
        int midCode_constNumber(int cn){
            int i = 0,now = Tree[cn].children[0];
            assert(Tree[now].tk == tokenType::INTCON);
            int con = stoi(Tree[now].tkContent);
            return con;
        }
        int midCode_constUnaryExp(int cue){
            int i=0,now = Tree[cue].children[0];
            if(Tree[now].gi == GrammarItem::PrimaryExp) return midCode_constPrimaryExp(now);
            assert(Tree[now].gi == GrammarItem::UnaryOp);
            opType op = midCode_unaryOp(now);
            now = Tree[cue].children[++i];
            assert(Tree[now].gi == GrammarItem::UnaryExp);
            if(op == opType::mov) return midCode_constUnaryExp(now);
            if(op == opType::neg) return -midCode_constUnaryExp(now);
            if(op == opType::NOT) return midCode_constUnaryExp(now)?0:1;
            assert(1<0);
            return -1;
        }
        int midCode_constAddExp(int cae){
            int i = 0,now = Tree[cae].children[0];
            if(Tree[now].gi == GrammarItem::MulExp) return midCode_constMulExp(now);
            assert(Tree[now].gi == GrammarItem::AddExp);
            int res1 = midCode_constAddExp(now);
            now = Tree[cae].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[cae].children[++i];
            assert(Tree[now].gi == GrammarItem::MulExp);
            int res2 = midCode_constMulExp(now);
            if(op == opType::plus) return res1+res2;
            if(op == opType::minu) return res1- res2;
            assert(1<0);
            return -1;
        }
        int midCode_constMulExp(int cme){
            int i = 0,now = Tree[cme].children[0];
            if(Tree[now].gi == GrammarItem::UnaryExp) return midCode_constUnaryExp(now);
            assert(Tree[now].gi == GrammarItem::MulExp);
            int res1 = midCode_constMulExp(now);
            now = Tree[cme].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[cme].children[++i];
            assert(Tree[now].gi == GrammarItem::UnaryExp);
            int res2 = midCode_constUnaryExp(now);
            if(op == opType::mult) return res1*res2;
            if(op == opType::DIV) return res1/res2;
            if(op == opType::mod) return res1 % res2;
            assert(1<0);
            return -1;
        }
        int midCode_constRelExp(int cre){
            int i = 0,now = Tree[cre].children[0];
            if(Tree[now].gi == GrammarItem::AddExp) return midCode_constAddExp(now);
            assert(Tree[now].gi == GrammarItem::RelExp);
            int res1 = midCode_constRelExp(now);
            now = Tree[cre].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[cre].children[++i];
            assert(Tree[now].gi == GrammarItem::AddExp);
            int res2 = midCode_constAddExp(now);
            if(op == opType::gre) return res1>res2? 1:0;
            if(op == opType::geq) return res1>=res2? 1:0;
            if(op == opType::lss) return res1<res2? 1:0;
            if(op == opType::leq) return res1<=res2? 1:0;
            assert(1<0);
            return -1;
        }
        int midCode_constEqExp(int cee){
            int i = 0,now = Tree[cee].children[0];
            if(Tree[now].gi == GrammarItem::RelExp) return midCode_constRelExp(now);
            assert(Tree[now].gi == GrammarItem::EqExp);
            int res1 = midCode_constEqExp(now);
            now = Tree[cee].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[cee].children[++i];
            assert(Tree[now].gi == GrammarItem::RelExp);
            int res2 = midCode_constRelExp(now);
            if(op == opType::eql) return res1==res2? 1:0;
            if(op == opType::neq) return res1==res2? 0:1;
            
            assert(1<0);
            return -1;
        }
        int midCode_constLAndExp(int lae){
            int i = 0,now = Tree[lae].children[0];
            if(Tree[now].gi == GrammarItem::EqExp) return midCode_constEqExp(now);
            assert(Tree[now].gi == GrammarItem::LAndExp);
            int res1 = midCode_constLAndExp(now);
            now = Tree[lae].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[lae].children[++i];
            assert(Tree[now].gi == GrammarItem::EqExp);
            int res2 = midCode_constEqExp(now);
            return res1*res2; 
        }



        int midCode_constLOrExp(int cle){
            int i = 0,now = Tree[cle].children[0];
            if(Tree[now].gi == GrammarItem::LAndExp) return midCode_constLAndExp(now);
            assert(Tree[now].gi == GrammarItem::LOrExp);
            int res1 = midCode_constLOrExp(now); 
            now = Tree[cle].children[++i];
            opType op = midCode_BiOp(now);
            now = Tree[cle].children[++i];
            assert(Tree[now].gi == GrammarItem::LAndExp);
            int res2 = midCode_constLAndExp(now);
            return (res1+res2)?1:0;
        }
};
void dfs_change(int p){
    if(Tree[p].tk == tokenType::IDENFR){
        //cout<<tokenType2string(Tree[p].tk)<<endl;
        if(Tree[p].blockid>0)
        Tree[p].tkContent = Tree[p].tkContent + "#" + to_string(Tree[p].blockid);
        //cout<<Tree[p].tkContent<<endl;
    }
    if(Tree[p].children.size()==0) return;
    for(auto son:Tree[p].children){
        dfs_change(son);
    }
}
void changeVarName(){
    int root = 1;
    dfs_change(root);
}
static int baseSize = 8;
static int savedRegSize = 32;
class MipsFuncContent {
    public:
        int argumentOffset;
        int localVarOffset;
        int tempRegOffset;
        int savedRegOffset;
        int baseOffset;
        int frameSize;
        MipsFuncContent(int tempRegSize, int localVarSize, int argumentSize) {
            argumentOffset = 0;
            localVarOffset = argumentOffset + argumentSize;
            tempRegOffset = localVarOffset + localVarSize;
            savedRegOffset = tempRegOffset + tempRegSize;
            baseOffset = savedRegOffset + savedRegSize;
            frameSize = baseOffset + baseSize;
        }
        MipsFuncContent(){
            argumentOffset = localVarOffset = tempRegOffset = savedRegOffset  = baseOffset = frameSize = 0;
        }
        void printInfo(){
            cout<<(to_string(argumentOffset) + " " + to_string(localVarOffset) + " " + to_string(savedRegOffset) + " " + to_string(baseOffset) + " " + to_string(frameSize))<<endl;
        }
};
class MipsDataContent{
    public:
        MipsDataClass type;
        string content;
        MipsDataContent(){
            this->type = MipsDataClass::asciiz;
            this->content = "";
        }
        MipsDataContent(MipsDataClass type,string str){
            this->type = type;
            this->content = str;
        }
        string getInfo(){
            string ans = "";
            if(type == MipsDataClass::asciiz) ans = "\t.asciiz";
            if(type == MipsDataClass::word) ans = "\t.word";
            if(type == MipsDataClass::space) ans = "\t.space";
            return ans+" "+content;
        }
} ;
class MipsText{
    public:
        MipsTextClass type;
        string content;
        MipsText(MipsTextClass type,string content){
            this->type = type;
            this->content = content;
        }
        string getInfo(){
            if(type == MipsTextClass::explaint) return "# "+content;
            if(type == MipsTextClass::syscall) return "\tsyscall";
            if(type == MipsTextClass::LABEL) return content+":";
            return "\t"+MipsTextClass2string[type]+" "+content;
        }
};
class MipsData{
    public:
        string LABEL;
        MipsDataContent lastDirective;
        vector<MipsDataContent> data;
        MipsData(string LABEL){
            this->LABEL = LABEL;
        }
        void addDirective(MipsDataClass type,string o){
            string content = o;
            if(data.size()==0 || type!=lastDirective.type){
                lastDirective = MipsDataContent(type,content);
                data.push_back(lastDirective);
                
                return;
            } 
            if(type == MipsDataClass::word) {
                data[data.size()-1].content =data[data.size()-1].content +  "," + content;
                return;
            }
            if(type == MipsDataClass::space) {
                int a = atoi(lastDirective.content.c_str());
                int b = atoi(content.c_str());
                data[data.size()-1].content = to_string(a+b);
                return;
            }
            if(type == MipsDataClass::asciiz) {
                data[data.size()-1].content = content;
                return;
            }
        }
        string getInfo(){
            string sb = LABEL + ":\n";
            for(auto it:data){
                sb = sb+it.getInfo();
            }
            return sb;
        }
};
static int regNum_s;
static int regNum_a;
static int intSize;
int TimeTotal = 0;
class MipsTranslator{
    public:

        void init(){
            regNum_s = 8;
            regNum_a = 4;
            intSize = 4;
            length = midCode.size();
            currentIndex = -1;
            getNext();
            work();
        }    
        vector<midCodeLine> midCode;
        int currentIndex;
        int length;
        midCodeLine nowMidCode;
        string funcName;
        int paramNum;
        MipsFuncContent funcContent;
        int localVarOffset;
        map<string,int> varInfoMap;
        map<string,MipsFuncContent> funcInfoMap;
        map<string,int> addressMap;
        int constStringIndex = 1;
        map<string,int> constStringMap;
        map<string,int> funcNameMap;
        set<string> dataName;
        vector<MipsData> dataSeg;
        vector<MipsText> textSeg;
        int currentRegIndex = 0;
        MipsTranslator (vector<midCodeLine> mc,map<string,int> vIP){
            this->midCode = mc;
            this->varInfoMap = vIP;
            
        }
        int getFreeReg(){
            return currentRegIndex ++;
        }
        int freeReg(){
            currentRegIndex --;
            assert(currentRegIndex>=0);
            return currentRegIndex;
        }
        void work(){
            for(int index = 0;index<midCode.size();){
                auto iq = midCode[index++];
                if(iq.op == opType::func_begin){
                    string funcName = iq.arg1;
                    int savedRegSize = 0;
				    int localVarSize = 0;
				    int argumentSize = 0;
                    iq = midCode[index++];
                    while(iq.op != opType::func_end){
                        if(iq.op == opType::alloc) localVarSize += atoi(iq.arg2.c_str());
                        if(iq.op == opType::call){
                            int size = varInfoMap[iq.arg1]*4;
                            if(size>argumentSize) argumentSize = size;
                        }
                        if(iq.op == opType::save){
                            int index = atoi(iq.arg1.c_str()) + 1;
                            if(index *4 >savedRegSize) savedRegSize = index*4; 
                        }
                        iq  = midCode[index++];
                    }
                    funcInfoMap[funcName]  = MipsFuncContent(savedRegSize, localVarSize, argumentSize); //
                }
            }
        }
        void getNext(){
            currentIndex++;
            nowMidCode = getMidCode(currentIndex);
        }
        midCodeLine getMidCode(int index){
            if(index>=0 && index<length)
            return midCode[index];
            return midCodeLine(opType::null,"","","");
        }
        void putText(MipsTextClass type,string content){
            textSeg.emplace_back(type,content);
        }
        int getStringIndex(string str){
            if(constStringMap.count(str)) return constStringMap[str];
            while(dataName.count("str"+to_string(constStringIndex))) constStringIndex++;
            constStringMap[str] = constStringIndex;
            return constStringIndex++;
        }
        opType typeOf(midCodeLine iq){
            return iq.op; 
        }
        void printInfo(){
            freopen("mips.txt","w",stdout);
            cout<<".data"<<endl;

            for(auto it:dataSeg){
                cout<<it.getInfo()<<endl;
            }
            cout<<".text"<<endl;
            for(auto it:textSeg){
                cout<<it.getInfo()<<endl;
            }
            freopen("","w",stdout);
        }
        void addStringConst(){
            for(auto p:constStringMap){
                MipsData constStr = MipsData("str"+to_string(p.second));
                constStr.addDirective(MipsDataClass::asciiz,"\""+p.first+"\"");
                dataSeg.push_back(constStr);
            }
            //freopen("","w",stdout);
        }
        void process(){
            putText(MipsTextClass::j,"main");
            while(typeOf(nowMidCode)== opType::alloc){
                allocGlobalVar();
            }
            while(typeOf(nowMidCode)== opType::func_begin){
                funcDef();
            }
            addStringConst();
        }
        void allocGlobalVar(){
            string name = nowMidCode.arg1;
            int size = atoi(nowMidCode.arg2.c_str());
            MipsData globalVar = MipsData(name);
            int offset = 0;
            getNext();
            for(;offset<size;offset+=4){
                if(nowMidCode.op != opType::sw) break;
                if(nowMidCode.arg1 != name) break;
                int nextOffset = atoi(nowMidCode.arg2.c_str());
                int value = atoi(nowMidCode.arg3.c_str());
                if(offset < nextOffset) globalVar.addDirective(MipsDataClass::space, to_string(nextOffset - offset));
                offset = nextOffset;
                globalVar.addDirective(MipsDataClass::word, to_string(value));
                getNext();
            }
            if(offset < size) globalVar.addDirective(MipsDataClass::space,to_string(size-offset));
            dataName.insert(name);
            dataSeg.push_back(globalVar);
        }
        void funcFParams(){
            getNext();
            while(typeOf(nowMidCode) == opType::fparam){
                string argName = nowMidCode.arg1;
                int argIndex = atoi(nowMidCode.arg3.c_str());
                if(argIndex<4){
                    putText(MipsTextClass::sw,"$a"+to_string(argIndex)+","+to_string(funcContent.frameSize+4*argIndex)+"($sp)");
                }
                addressMap[argName] = 4*argIndex;
                getNext();
            }
        }
        void funcDef(){
            int funcIndex = atoi(nowMidCode.arg3.c_str());
            funcNameMap[nowMidCode.arg1] = funcIndex;
            funcName = "f"+to_string(funcIndex);
            if(nowMidCode.arg1 == "main") funcName = "main";
            putText(MipsTextClass::LABEL,funcName);
            funcContent = funcInfoMap[nowMidCode.arg1];
            paramNum = varInfoMap[nowMidCode.arg1];
            putText(MipsTextClass::addiu,"$sp,$sp,-"+to_string(funcContent.frameSize));
            putText(MipsTextClass::sw,"$ra,"+to_string(funcContent.baseOffset+4)+"($sp)");
            putText(MipsTextClass::sw,"$fp,"+to_string(funcContent.baseOffset)+"($sp)");
            putText(MipsTextClass::MOVE,"$fp,$sp");
            funcFParams();
            localVarOffset = funcContent.localVarOffset;
            while(typeOf(nowMidCode)!=opType::func_end) stmt();
            putText(MipsTextClass::LABEL,funcName+"_return");
            if(funcName == "main"){
                putText(MipsTextClass::li,"$v0,10");
                putText(MipsTextClass::syscall,"");
            }
            putText(MipsTextClass::MOVE,"$sp,$fp");
            putText(MipsTextClass::lw,"$fp,"+to_string(funcContent.baseOffset)+"($sp)");
            putText(MipsTextClass::lw,"$ra,"+to_string(funcContent.baseOffset+4)+"($sp)");
            putText(MipsTextClass::addiu,"$sp,$sp,"+to_string(funcContent.frameSize));
            putText(MipsTextClass::jr,"$ra");
            getNext();
        }
        void stmt(){
            if(nowMidCode.op == opType::alloc){
                allocVar();
            }else if(nowMidCode.op == opType::func_return){
                funcReturn();   
            }else if(nowMidCode.op == opType::rparam){
                funcRparam();
            }else if(nowMidCode.op == opType::call){
                call();  
            }else if(nowMidCode.op == opType::save){
                save();
            }else if(nowMidCode.op == opType::load){
                load();
            }else if(nowMidCode.op == opType::print_string){
                printString();
            }else if(nowMidCode.op == opType::print_int){
                printInt();
            }else if(nowMidCode.op == opType::get_int){
                getInt();
            }else if(nowMidCode.op == opType::if_begin){
                ifBegin();
            }else if(nowMidCode.op == opType::else_begin){
                elseBegin();
            }else if(nowMidCode.op == opType::if_end){
                ifEnd();
            }else if(nowMidCode.op == opType::for_begin){
                forBegin();
            }else if(nowMidCode.op == opType::for_cond){
                forCond();
            }else if(nowMidCode.op == opType::for_auto){
                forAuto();
            }else if(nowMidCode.op == opType::for_end){
                forEnd();
            }else if(nowMidCode.op == opType::for_break){
                forBreak();
            }else if(nowMidCode.op == opType::for_continue){
                forContinue();
            }else if(nowMidCode.op == opType::func_end){
                
            }else calstmt();
            getNext();
        }
        void allocVar(){
            string varName = nowMidCode.arg1;
            int size = atoi(nowMidCode.arg2.c_str());
            addressMap[varName] = localVarOffset - funcContent.frameSize;
            localVarOffset += size;
        }    
        void funcReturn(){
            string returnVal = nowMidCode.arg1;
            if(returnVal!=""){
                putText(MipsTextClass::MOVE,"$v0,"+returnVal);
            }
            putText(MipsTextClass::j,funcName+"_return");
        }
        void call(){
            string callee = "f"+to_string(funcNameMap[nowMidCode.arg1]);
            int cparamNum = varInfoMap[nowMidCode.arg1];
            for(int paramIndex = cparamNum-1;paramIndex>=0;paramIndex--){
                int regIndex = freeReg();
                if(paramIndex<4 && regIndex<regNum_s){
                    putText(MipsTextClass::MOVE,"$a"+to_string(paramIndex)+",$s"+to_string(regIndex));
                }else if(regIndex<regNum_s){
                    putText(MipsTextClass::sw,"$s"+to_string(regIndex)+","+to_string(paramIndex*4)+"($sp)");
                }else if(paramIndex<4){
                    putText(MipsTextClass::lw,"$a"+to_string(paramIndex)+","+to_string(funcContent.savedRegOffset+regIndex*4));
                }else {
                    putText(MipsTextClass::lw,"$v1,"+to_string(funcContent.savedRegOffset+regIndex*4)+"($sp)");
                    putText(MipsTextClass::sw,"$v1,"+to_string(paramIndex*4)+"($sp)");
                }
            }
            putText(MipsTextClass::jal,callee);
            for(int regIndex=0;regIndex<min(regNum_s,currentRegIndex);regIndex++){
                putText(MipsTextClass::lw,"$s"+to_string(regIndex)+","+to_string(funcContent.savedRegOffset+regIndex*4)+"($sp)");
            }
            for(int regIndex = 0;regIndex<4 && regIndex<paramNum;regIndex++){
                int offset = funcContent.frameSize+regIndex*4;
                putText(MipsTextClass::lw,"$a"+to_string(regIndex)+","+to_string(offset)+"($sp)");
            }
        }
        void save(){
            int regIndex = atoi(nowMidCode.arg3.c_str());
            int savedRegIndex = atoi(nowMidCode.arg1.c_str());
            putText(MipsTextClass::sw,"$t"+to_string(regIndex)+","+to_string(funcContent.tempRegOffset+savedRegIndex*4)+"($sp)");
        }
        void load(){
            int regIndex = atoi(nowMidCode.arg3.c_str());
            int savedRegIndex = atoi(nowMidCode.arg1.c_str());
            putText(MipsTextClass::lw,"$t"+to_string(regIndex)+","+to_string(funcContent.tempRegOffset+savedRegIndex*4)+"($sp)");
        }
        void funcRparam(){
            string argName = nowMidCode.arg1;
            int regIndex = getFreeReg();
            if(regIndex<regNum_s) putText(MipsTextClass::MOVE,"$s"+to_string(regIndex)+","+argName);
            putText(MipsTextClass::sw,argName+","+to_string(funcContent.savedRegOffset+regIndex*4)+"($sp)");
        }
        void printInt(){
            string argName = nowMidCode.arg1;
            putText(MipsTextClass::MOVE, "$v1,$a0");
            putText(MipsTextClass::li, "$v0,1");
            putText(MipsTextClass::MOVE, "$a0,"+argName);
            putText(MipsTextClass::syscall, "");
            putText(MipsTextClass::MOVE, "$a0,$v1");
        }
        void getInt(){
            putText(MipsTextClass::li, "$v0,5");
            putText(MipsTextClass::syscall, "");
        }
        void ifBegin(){
            string cond = nowMidCode.arg1;
            string ifIndex = nowMidCode.arg3;
            putText(MipsTextClass::beqz,cond+","+"else"+ifIndex);
            putText(MipsTextClass::explaint,cond+","+"ifbegin"+ifIndex);
        }
        void elseBegin(){
            string ifIndex = nowMidCode.arg3;
            putText(MipsTextClass::j,"ifend"+ifIndex);
            putText(MipsTextClass::LABEL,"else"+ifIndex);
        }
        void ifEnd(){
            string ifIndex = nowMidCode.arg3;
            putText(MipsTextClass::LABEL,"ifend"+ifIndex);
        }
        void forBegin(){
            string forIndex = nowMidCode.arg3;
		    putText(MipsTextClass::LABEL,"for"+forIndex);
        }
        void forAuto(){
            string forIndex = nowMidCode.arg3;
            putText(MipsTextClass::LABEL,"forauto"+forIndex);
        }
        void forEnd(){
            string forIndex = nowMidCode.arg3;
            putText(MipsTextClass::j,"for"+forIndex);
            putText(MipsTextClass::LABEL,"forend"+forIndex);
        }
        void forCond(){
            string cond = nowMidCode.arg1;
		    string forIndex = nowMidCode.arg3;
		    if(cond!="")putText(MipsTextClass::beqz,cond+","+"forend"+forIndex);
		    putText(MipsTextClass::explaint,"forcond"+forIndex);
        }
        void forBreak() {
            string forIndex = nowMidCode.arg3;
            putText(MipsTextClass::j,"forend"+forIndex);
        }
        void forContinue() {
            string forIndex = nowMidCode.arg3;
            putText(MipsTextClass::j,"forauto"+forIndex);
        }
        void printString(){
            string str = nowMidCode.arg1;
            int strIndex = getStringIndex(str);
            putText(MipsTextClass::MOVE, "$v1,$a0");
		    putText(MipsTextClass::li, "$v0,4");
		    putText(MipsTextClass::la, "$a0,str"+to_string(strIndex));
		    putText(MipsTextClass::syscall, "");
		    putText(MipsTextClass::MOVE, "$a0,$v1");
        }
        void calstmt(){
            string arg1 = nowMidCode.arg1;
            string arg2 = nowMidCode.arg2;
            string res = nowMidCode.arg3;
            if(nowMidCode.op == opType::plus){
                putText(MipsTextClass::add,res+","+arg1+","+arg2);
                //cout<<arg1<<' '<<arg2<<endl;
            }else if(nowMidCode.op == opType::minu){
                putText(MipsTextClass::sub,res+","+arg1+","+arg2);
            }else if(nowMidCode.op == opType::mult){
                if(arg2[0]!='$'){
                    putText(MipsTextClass::li,"$v1,"+arg2);
                    arg2 = "$v1";
                }
                putText(MipsTextClass::mult,arg1+","+arg2);
                putText(MipsTextClass::mflo,res);
            }else if(nowMidCode.op == opType::DIV){
                putText(MipsTextClass::DIV,arg1+","+arg2);
                putText(MipsTextClass::mflo,res);
            }else if(nowMidCode.op == opType::mod){
                putText(MipsTextClass::DIV,arg1+","+arg2);
                putText(MipsTextClass::mfhi,res);
            }else if(nowMidCode.op == opType::lss){
                putText(MipsTextClass::sgt,res+","+arg2+","+arg1);
            }else if(nowMidCode.op == opType::leq){
                putText(MipsTextClass::sle,res+","+arg1+","+arg2);
            }else if(nowMidCode.op == opType::gre){
                putText(MipsTextClass::sgt,res+","+arg1+","+arg2);
            }else if(nowMidCode.op == opType::geq){
                putText(MipsTextClass::sge,res+","+arg1+","+arg2);
            }else if(nowMidCode.op == opType::eql){
                putText(MipsTextClass::seq,res+","+arg1+","+arg2);
            }else if(nowMidCode.op == opType::neq){
                putText(MipsTextClass::sne,res+","+arg1+","+arg2);
            }else if(nowMidCode.op == opType::mov){
                if(res!=arg1) putText(MipsTextClass::MOVE,res+","+arg1);
            }else if(nowMidCode.op == opType::neg){
                putText(MipsTextClass::sub,res+",$0,"+arg1);
            }else if(nowMidCode.op == opType::NOT){
                putText(MipsTextClass::seq,res+",$0,"+arg1);
            }else if(nowMidCode.op == opType::li){
                putText(MipsTextClass::li,res+","+arg1);
            }else if(nowMidCode.op == opType::lw){
                if(arg1[0]!='$'){
                    if(addressMap.count(arg1)){
                        int offset = addressMap[arg1];
                        int dim = varInfoMap[arg1+"@"];
                        if(offset >=0 && dim>0){
                            if(offset<16){
                                putText(MipsTextClass::add,"$v1,$a"+to_string(offset/4)+","+arg2);
                            }else {
                                putText(MipsTextClass::lw,"$v1,"+to_string(funcContent.frameSize+offset)+"($sp)");
                                putText(MipsTextClass::add,"$v1,$v1,"+arg2);
                            }
                            putText(MipsTextClass::lw,res+",0($v1)");
                        }else{
                            if(offset>=0 && offset<16){
                                putText(MipsTextClass::MOVE,res+",$a"+to_string(offset/4));
                            }else{
                                putText(MipsTextClass::add,"$v1,$sp,"+arg2);
                                putText(MipsTextClass::lw,res+","+to_string(funcContent.frameSize+offset)+"($v1)");
                            }
                        }
                    }else{
                        putText(MipsTextClass::la,"$v1,"+arg1);
                        putText(MipsTextClass::add,"$v1,$v1,"+arg2);
                        putText(MipsTextClass::lw,res+",0($v1)"); 
                    }
                }else assert(1<0);
            }else if(nowMidCode.op == opType::sw){
                if(res[0]!='$'){
                    putText(MipsTextClass::li,"$v0,"+res);
                    res = "$v0";
                }
                if(arg1[0]!='$'){
                    if(addressMap.count(arg1)){
                        int offset = addressMap[arg1];
                        int dim = varInfoMap[arg1+"@"];
                        if(offset >=0 && dim>0){
                            if(offset<16){
                                putText(MipsTextClass::add,"$v1,$a"+to_string(offset/4)+","+arg2);
                            }else {
                                putText(MipsTextClass::lw,"$v1,"+to_string(funcContent.frameSize+offset)+"($sp)");
                                putText(MipsTextClass::add,"$v1,$v1,"+arg2);
                            }
                            putText(MipsTextClass::sw,res+",0($v1)");
                        }else{
                            if(offset>=0 && offset<16)
                                putText(MipsTextClass::MOVE,"$a"+to_string(offset/4)+","+res);
                            putText(MipsTextClass::add,"$v1,$sp,"+arg2);
                            putText(MipsTextClass::sw,res+","+to_string(funcContent.frameSize+offset)+"($v1)");
                            
                        }
                    }else {
                        putText(MipsTextClass::la, "$v1,"+arg1);
                        putText(MipsTextClass::add, "$v1,$v1,"+arg2);
                        putText(MipsTextClass::sw, res+",0($v1)");
                    }
                }else assert(1<0);
            }else if(nowMidCode.op == opType::address){
                if(arg1[0]!='$'){
                    if(addressMap.count(arg1)){
                        int offset = addressMap[arg1];
                        int dim = varInfoMap[arg1+"@"];
                        if(offset >=0 && dim>0){
                            if(offset<16){
                                putText(MipsTextClass::add,res+",$a"+to_string(offset/4)+","+arg2);
                            }else {
                                putText(MipsTextClass::lw,"$v1,"+to_string(funcContent.frameSize+offset)+"($sp)");
                                putText(MipsTextClass::add,res+",$v1,"+arg2);
                            }
                        }else{
                            putText(MipsTextClass::add, "$v1,$sp,"+arg2);
                            putText(MipsTextClass::addiu,  res+",$v1,"+to_string(funcContent.frameSize + offset));
                        }
                    }else {
                        putText(MipsTextClass::la, "$v1,"+arg1);
                        putText(MipsTextClass::add, res + ",$v1,"+arg2);
                    }
                }else assert(1<0);
            }else {
                cout<<opType2string[nowMidCode.op]<<endl;
                assert(1<0);
            }
        }

};

string textLine;
void pre_optimize(){
    char c;
    string temp = text;
    text = "";
    int len = temp.length();

    for(int i=0;i<len;){
        if((temp[i]=='-' || temp[i]=='+') && temp[i+1]=='0' && (temp[i+2] == '+' || temp[i+2] == '-' || temp[i+2] == ',' || temp[i+2]==';' || temp[i+2] == ')'))
        {
            i = i+2;
        }    else{
            text  = text + temp[i];
            i++;
        }
        
    }
}
int main(){
    ifstream file("testfile.txt");
    //freopen("output.txt", "w", stdout);
    //srand(time(0));
    
    
    while(getline(file, textLine)){
        text= text+textLine+'\n';
    }   
    //pre_optimize();
    //cout<<text<<endl;
    Lexer newLexer(text);
    file.close();
    needAnswer1 = 0,needAnswer2 = 0,needAnswer3 = 1,needAnswer4 = 1;
    newLexer.run();
    if(needAnswer1)
    for(auto p:newLexer.Result){
        cout<<tokenType2string(p.tk)<<" "<<p.content<<endl;
    }
    
    Parser newParser(newLexer.Result);
    int rt = newParser.run();
    if(needAnswer2){
        
        newParser.Output(rt);
    }
    if(needAnswer3){
        freopen("error.txt", "w", stdout);
        for(auto p :errorList) cout<<p.first<<' '<<errorCode[p.second]<<endl;
    }
    if(!errorList.empty()){
        return 0;
    }
    Intermediator newIntermediator;
    
    if(needAnswer4){
        //freopen("midcode.txt", "w", stdout);
        changeVarName();
        newIntermediator.process();
        newIntermediator.printInfo();

        MipsTranslator mts = MipsTranslator(newIntermediator.midCode, newIntermediator.varInfoMap);
        mts.init();
        mts.process();
        mts.printInfo();
    }

    return 0;
}